
#if 0
#endif
// 1
/*
 * bitXor - x^y using only ~ and &
 *   Example: bitXor(4, 5) = 1
 *   Legal ops: ~ &
 *   Max ops: 14
 *   Rating: 1
 */
int bitXor(int x, int y)
{
  /* x ^ y = (~(x & y)) & (~(~x & ~y)) */
  int a = x & y;
  int b = (~x) & (~y);
  return (~a) & (~b);
}
/*
 * tmin - return minimum two's complement integer
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 4
 *   Rating: 1
 */
int tmin(void)
{
  return 1 << 31;
}
// 2
/*
 * isTmax - returns 1 if x is the maximum, two's complement number,
 *     and 0 otherwise
 *   Legal ops: ! ~ & ^ | +
 *   Max ops: 10
 *   Rating: 2
 */
int isTmax(int x)
{
  int y = x + 1;
  return !(x ^ ~y) & (!!y);
}
/*
 * allOddBits - return 1 if all odd-numbered bits in word set to 1
 *   Examples allOddBits(0xFFFFFFFD) = 0, allOddBits(0xAAAAAAAA) = 1
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 12
 *   Rating: 2
 */
int allOddBits(int x)
{
  int mask = 0xAA;
  mask = mask | (mask << 8);
  mask = mask | (mask << 16);
  return !((x & mask) ^ mask);
}
/*
 * negate - return -x
 *   Example: negate(1) = -1.
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 5
 *   Rating: 2
 */
int negate(int x)
{
  return ~x + 1;
}
// 3
/*
 * isAsciiDigit - return 1 if 0x30 <= x <= 0x39 (ASCII codes for characters '0' to '9')
 *   Example: isAsciiDigit(0x35) = 1.
 *            isAsciiDigit(0x3a) = 0.
 *            isAsciiDigit(0x05) = 0.
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 15
 *   Rating: 3
 */
int isAsciiDigit(int x)
{
  int lo = x + (~0x30 + 1); /* x - 0x30 */
  int hi = 0x39 + (~x + 1); /* 0x39 - x */
  int lo_ok = !(lo >> 31);  /* x >= 0x30 */
  int hi_ok = !(hi >> 31);  /* x <= 0x39 */
  return lo_ok & hi_ok;
}
/*
 * conditional - same as x ? y : z
 *   Example: conditional(2,4,5) = 4
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 16
 *   Rating: 3
 */
int conditional(int x, int y, int z)
{
  int t = !!x;
  int mask = ~t + 1;
  return (mask & y) | (~mask & z);
}
/*
 * isLessOrEqual - if x <= y  then return 1, else return 0
 *   Example: isLessOrEqual(4,5) = 1.
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 24
 *   Rating: 3
 */
int isLessOrEqual(int x, int y)
{

  int sign_x = x >> 31;
  int sign_y = y >> 31;
  int diff_sign_result = sign_x & !sign_y;
  int same_sign = !(sign_x ^ sign_y);
  int sub = y + ((~x) + 1);
  int is_non_negative = !(sub >> 31);
  int same_sign_result = same_sign & is_non_negative;
  return diff_sign_result | same_sign_result;
}
// 4
/*
 * logicalNeg - implement the ! operator, using all of
 *              the legal operators except !
 *   Examples: logicalNeg(3) = 0, logicalNeg(0) = 1
 *   Legal ops: ~ & ^ | + << >>
 *   Max ops: 12
 *   Rating: 4
 */
int logicalNeg(int x)
{

  int sign_mask = (x | (~x + 1)) >> 31;

  return sign_mask + 1;
}
/* howManyBits - return the minimum number of bits required to represent x in
 *             two's complement
 *  Examples: howManyBits(12) = 5
 *            howManyBits(298) = 10
 *            howManyBits(-5) = 4
 *            howManyBits(0)  = 1
 *            howManyBits(-1) = 1
 *            howManyBits(0x80000000) = 32
 *  Legal ops: ! ~ & ^ | + << >>
 *  Max ops: 90
 *  Rating: 4
 */
int howManyBits(int x)
{
  int s = x >> 31;
  int a = x ^ s;
  int b16;
  int b8;
  int b4;
  int b2;
  int b1;
  int b0;
  b16 = !!(a >> 16) << 4;
  a = a >> b16;
  b8 = !!(a >> 8) << 3;
  a = a >> b8;
  b4 = !!(a >> 4) << 2;
  a = a >> b4;
  b2 = !!(a >> 2) << 1;
  a = a >> b2;
  b1 = !!(a >> 1);
  a = a >> b1;
  b0 = a;
  return b16 + b8 + b4 + b2 + b1 + b0 + 1;
}
// float
/*
 * float_twice - Return bit-level equivalent of expression 2*f for
 *   floating point argument f.
 *   Both the argument and result are passed as unsigned int's, but
 *   they are to be interpreted as the bit-level representation of
 *   single-precision floating point values.
 *   When argument is NaN, return argument
 *   Legal ops: Any integer/unsigned operations incl. ||, &&. also if, while
 *   Max ops: 30
 *   Rating: 4
 */
unsigned float_twice(unsigned uf)
{
  unsigned sign = uf & 0x80000000u;
  unsigned exp = (uf >> 23) & 0xFFu;
  unsigned frac = uf & 0x7FFFFFu;

  if (exp == 0xFFu)
  {
    return uf;
  }
  if (exp == 0u)
  {
    frac <<= 1;
    if (frac & 0x800000u)
    {
      exp = 1u;
      frac &= 0x7FFFFFu;
    }
    return sign | (exp << 23) | frac;
  }
  exp += 1u;
  if (exp == 0xFFu)
  {
    frac = 0u;
  }
  return sign | (exp << 23) | frac;
}
/*
 * float_i2f - Return bit-level equivalent of expression (float) x
 *   Result is returned as unsigned int, but
 *   it is to be interpreted as the bit-level representation of a
 *   single-precision floating point values.
 *   Legal ops: Any integer/unsigned operations incl. ||, &&. also if, while
 *   Max ops: 30
 *   Rating: 4
 */
unsigned float_i2f(int x)
{
  unsigned sign = x >> 31 & 1, exp, frac, round;
  int x_exp, frac_mask;
  if (!x) 
    return 0;
  if (!(x ^ (1 << 31))) 
    return 0xcf << 24;
  if (sign)
    x = -x;
  x_exp = 31;
  while (!(x >> x_exp))
    x_exp--;
  exp = x_exp + 0x7f; 
  x <<= (31 - x_exp); 
  frac_mask = 0x7fffff;
  
  frac = (x >> 8) & frac_mask;
  round = x & 0xff;                                          
  frac += ((round > 0x80) || ((round == 0x80) && (frac & 1))); 
  if (frac >> 23)
  {
    frac &= frac_mask;
    exp += 1;
  }
  return sign << 31 | exp << 23 | frac;
}
/*
 * float_f2i - Return bit-level equivalent of expression (int) f
 *   for floating point argument f.
 *   Argument is passed as unsigned int, but
 *   it is to be interpreted as the bit-level representation of a
 *   single-precision floating point value.
 *   Anything out of range (including NaN and infinity) should return
 *   0x80000000u.
 *   Legal ops: Any integer/unsigned operations incl. ||, &&. also if, while
 *   Max ops: 30
 *   Rating: 4
 */
int float_f2i(unsigned uf)
{
  int exp = (uf >> 23) & 0xFF;
  int sign = uf >> 31;
  int frac = uf & 0x7FFFFF;
  int E = exp - 127;
  int M;
  int val;
  if (exp == 0xFF)
    return 0x80000000u;
  if (E < 0)
    return 0;
  if (E > 30)
    return 0x80000000u;
  M = (1 << 23) | frac;
  if (E >= 23)
    val = M << (E - 23);
  else
    val = M >> (23 - E);
  if (sign)
    val = -val;
  return val;
}
