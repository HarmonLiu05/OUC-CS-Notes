DATA SEGMENT
    SCORES DB 56, 69, 84, 82, 73, 88, 99, 63, 100, 80  ; 成绩数组，共10个元素
    COUNT EQU 10                                      ; 数组元素个数
    S5 DB 0                                           ; <60分计数器
    S6 DB 0                                           ; 60-69分计数器
    S7 DB 0                                           ; 70-79分计数器
    S8 DB 0                                           ; 80-89分计数器
    S9 DB 0                                           ; 90-99分计数器
    S10 DB 0                                          ; 100分计数器
    MSG_RESULT DB 'Score statistics completed.$'
DATA ENDS

CODE SEGMENT
    ASSUME CS:CODE, DS:DATA
MAIN PROC
    MOV AX, DATA      ; 将数据段地址加载到 AX
    MOV DS, AX        ; 设置 DS 指向数据段

    ; 初始化计数器
    MOV SI, 0         ; SI 用作数组索引
    MOV CX, COUNT     ; CX 用作循环计数器

STAT_LOOP:
    ; 获取当前成绩
    MOV AL, SCORES[SI]  ; 将当前成绩加载到 AL
    
    ; 比较成绩范围并增加相应计数器
    CMP AL, 60        ; 比较是否小于60
    JL COUNT_S5       ; 如果小于60，跳转到S5计数
    
    CMP AL, 70        ; 比较是否小于70
    JL COUNT_S6       ; 如果小于70，跳转到S6计数
    
    CMP AL, 80        ; 比较是否小于80
    JL COUNT_S7       ; 如果小于80，跳转到S7计数
    
    CMP AL, 90        ; 比较是否小于90
    JL COUNT_S8       ; 如果小于90，跳转到S8计数
    
    CMP AL, 100       ; 比较是否小于100
    JL COUNT_S9       ; 如果小于100，跳转到S9计数
    
    CMP AL, 100       ; 比较是否等于100
    JE COUNT_S10      ; 如果等于100，跳转到S10计数
    
    ; 默认情况（虽然不应该发生，但为了完整性）
    JMP NEXT_SCORE

COUNT_S5:
    INC S5            ; S5计数器加1
    JMP NEXT_SCORE

COUNT_S6:
    INC S6            ; S6计数器加1
    JMP NEXT_SCORE

COUNT_S7:
    INC S7            ; S7计数器加1
    JMP NEXT_SCORE

COUNT_S8:
    INC S8            ; S8计数器加1
    JMP NEXT_SCORE

COUNT_S9:
    INC S9            ; S9计数器加1
    JMP NEXT_SCORE

COUNT_S10:
    INC S10           ; S10计数器加1

NEXT_SCORE:
    INC SI            ; 移动到下一个成绩
    LOOP STAT_LOOP    ; 循环处理下一个成绩

    ; 显示完成信息
    LEA DX, MSG_RESULT
    MOV AH, 09H
    INT 21H

    ; 程序结束
    MOV AH, 4CH
    INT 21H
MAIN ENDP
CODE ENDS
END MAIN