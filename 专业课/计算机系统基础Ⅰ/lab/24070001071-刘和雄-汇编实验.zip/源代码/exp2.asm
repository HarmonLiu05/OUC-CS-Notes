DATA SEGMENT
    X DW 1200H        ; 定义变量 X = 1200H
    Y DW 0034H        ; 定义变量 Y = 0034H
    Z DW 0F045H       ; 定义变量 Z = F045H
    W DW 034AH        ; 定义变量 W = 034AH
    RESULT_QUOTIENT DW ?  ; 商的结果存储位置
    RESULT_REMAINDER DW ? ; 余数的结果存储位置
DATA ENDS

CODE SEGMENT
    ASSUME CS:CODE, DS:DATA
START:
    MOV AX, DATA      ; 将数据段地址加载到 AX
    MOV DS, AX        ; 将 AX 的值赋给 DS，完成数据段初始化

    ; 计算 X*Y，结果为32位，高位在DX，低位在AX
    MOV AX, X
    MOV BX, Y
    MUL BX            ; AX = X * Y, 结果高位在 DX

    ; 加上 Z，处理进位
    ADD AX, Z
    ADC DX, 0         ; 处理高16位进位

    ; 减去 540，处理借位
    SUB AX, 540       ; 540 是十进制数
    SBB DX, 0         ; 处理高16位借位
    ; 此时 DX:AX 存放着 (X*Y + Z - 540) 的结果

    ; 计算 W - (X*Y + Z - 540)
    ; 先将中间结果保存起来
    MOV BX, AX        ; 保存低16位
    MOV CX, DX        ; 保存高16位

    ; 将 W 加载到 AX 并符号扩展为32位 (DX:AX)
    MOV AX, W
    CWD               ; 将 AX 符号扩展到 DX:AX

    ; 从 W 的32位表示中减去中间结果
    SUB AX, BX        ; 低16位减法
    SBB DX, CX        ; 高16位减法，考虑借位

    ; 此时 DX:AX 存放着 (W - (X*Y + Z - 540)) 的结果
    ; 开始除法运算
    MOV BX, X         ; 除数加载到 BX
    IDIV BX           ; 有符号除法，商在 AX，余数在 DX

    ; 将结果存储
    MOV RESULT_QUOTIENT, AX  ; 存储商
    MOV RESULT_REMAINDER, DX ; 存储余数

    ; 程序结束
    MOV AH, 4CH       ; DOS 功能号 4CH，用于终止程序
    INT 21H           ; 调用 DOS 中断
CODE ENDS
END START