DATA SEGMENT
    HEX_INPUT DB 5, ?, 5 DUP(?)  ; 定义输入缓冲区，最大5字节（4字符+回车）
    MSG_PROMPT DB 'Enter 4-digit hex number: $'
    MSG_OUTPUT DB 13, 10, 'Binary: $'
    BINARY_OUTPUT DB 17 DUP('0'), '$'  ; 16位二进制数+1个'$'结束符
DATA ENDS

CODE SEGMENT
    ASSUME CS:CODE, DS:DATA
MAIN PROC
    MOV AX, DATA      ; 将数据段地址加载到 AX
    MOV DS, AX        ; 设置 DS 指向数据段

    ; 显示提示信息
    LEA DX, MSG_PROMPT
    MOV AH, 09H
    INT 21H

    ; 读取用户输入的4位十六进制数
    LEA DX, HEX_INPUT
    MOV AH, 0AH       ; DOS 功能号 0AH，用于输入字符串
    INT 21H

    ; 解析输入的十六进制数
    XOR BX, BX        ; 清零 BX，用于存储解析出的16位数值
    MOV SI, 2         ; SI 指向输入缓冲区的第一个实际字符
    MOV CX, 4         ; 循环4次，处理4个十六进制字符

PARSE_LOOP:
    MOV AL, [SI]      ; 取当前字符
    CMP AL, '0'       ; 比较是否 >= '0'
    JL NEXT_CHAR      ; 如果小于 '0'，跳过
    CMP AL, '9'       ; 比较是否 <= '9'
    JLE DIGIT         ; 如果是数字，跳转到 DIGIT
    
    CMP AL, 'A'       ; 比较是否 >= 'A'
    JL NEXT_CHAR      ; 如果小于 'A'，跳过
    CMP AL, 'F'       ; 比较是否 <= 'F'
    JLE LETTER        ; 如果是字母 A-F，跳转到 LETTER
    
    CMP AL, 'a'       ; 比较是否 >= 'a'
    JL NEXT_CHAR      ; 如果小于 'a'，跳过
    CMP AL, 'f'       ; 比较是否 <= 'f'
    JLE LETTER_LOW    ; 如果是字母 a-f，跳转到 LETTER_LOW
    
    JMP NEXT_CHAR     ; 如果都不是，跳过

DIGIT:
    SUB AL, '0'       ; 将 ASCII 转换为数字
    JMP CONVERT_DONE

LETTER:
    SUB AL, 'A'       ; 将 ASCII 转换为数字
    ADD AL, 10        ; 加上 10
    JMP CONVERT_DONE

LETTER_LOW:
    SUB AL, 'a'       ; 将 ASCII 转换为数字
    ADD AL, 10        ; 加上 10

CONVERT_DONE:
    SHL BX, 1         ; 将当前值左移1位 (重复4次达到左移4位的效果)
    SHL BX, 1
    SHL BX, 1
    SHL BX, 1
    OR BL, AL         ; 将新数字加入到最低4位
    INC SI            ; 指向下一个字符

NEXT_CHAR:
    LOOP PARSE_LOOP   ; 循环处理下一个字符

    ; 现在 BX 中包含了16位的十六进制数值
    ; 将其转换为二进制表示
    MOV AX, BX        ; 将数值复制到 AX
    MOV CX, 16        ; 循环16次，处理16位
    LEA DI, BINARY_OUTPUT  ; DI 指向二进制输出缓冲区

CONVERT_BINARY:
    SHL AX, 1         ; 将最高位移到进位标志位
    JC SET_BIT_ONE    ; 如果进位标志为1，设置该位为'1'
    
    ; 设置该位为'0'
    MOV BYTE PTR [DI], '0'
    JMP NEXT_BIT

SET_BIT_ONE:
    MOV BYTE PTR [DI], '1'

NEXT_BIT:
    INC DI            ; 指向输出缓冲区的下一个位置
    LOOP CONVERT_BINARY  ; 循环处理下一位

    ; 显示转换结果
    LEA DX, MSG_OUTPUT
    MOV AH, 09H
    INT 21H

    ; 显示二进制数
    LEA DX, BINARY_OUTPUT
    MOV AH, 09H
    INT 21H

    ; 程序结束
    MOV AH, 4CH
    INT 21H
MAIN ENDP
CODE ENDS
END MAIN