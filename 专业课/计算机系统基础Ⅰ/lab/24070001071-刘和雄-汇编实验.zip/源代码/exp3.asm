DATA SEGMENT
    STRING1 DB 'Move the cursor backward.', 0  ; 定义字符串1，以0结尾
    STRING2 DB 'Move the cursor backward.', 0  ; 定义字符串2，以0结尾
    MSG_MATCH DB 'Match$'                     ; 匹配消息
    MSG_NOMATCH DB 'No match$'                ; 不匹配消息
    MSG_MODIFY DB 'Modifying String2...', 13, 10, '$'  ; 修改提示信息
    MSG_TEST_AGAIN DB 'Testing again...', 13, 10, '$'  ; 再次测试提示信息
DATA ENDS

CODE SEGMENT
    ASSUME CS:CODE, DS:DATA
MAIN PROC
    MOV AX, DATA      ; 将数据段地址加载到 AX
    MOV DS, AX        ; 设置 DS 指向数据段
    MOV ES, AX        ; 设置 ES 指向数据段（CMPSB指令需要）

    ; 第一次比较：相同的字符串
    LEA SI, STRING1   ; SI 指向字符串1
    LEA DI, STRING2   ; DI 指向字符串2

    ; 计算字符串长度（包括结束符0）
    MOV CX, 25        ; 字符串长度为25（'Move the cursor backward.' + '\0' = 24 + 1 = 25）

    ; 使用 REPE CMPSB 比较字符串
    REPE CMPSB        ; 当 CX != 0 且 ZF = 1 时重复比较

    ; 检查比较结果
    JNZ NOT_MATCH1    ; 如果 ZF = 0 (不相等)，跳转到 NOT_MATCH1

    ; 如果相等，显示 'Match'
    LEA DX, MSG_MATCH
    MOV AH, 09H
    INT 21H
    JMP CONTINUE

NOT_MATCH1:
    ; 如果不相等，显示 'No match'
    LEA DX, MSG_NOMATCH
    MOV AH, 09H
    INT 21H

CONTINUE:
    ; 输出换行
    MOV DL, 13        ; 回车
    MOV AH, 02H
    INT 21H
    MOV DL, 10        ; 换行
    MOV AH, 02H
    INT 21H

    ; 显示修改提示
    LEA DX, MSG_MODIFY
    MOV AH, 09H
    INT 21H

    ; 修改 STRING2 的第一个字符使其与 STRING1 不同
    MOV BYTE PTR [STRING2], 'N'  ; 将 'M' 改为 'N'

    ; 显示再次测试提示
    LEA DX, MSG_TEST_AGAIN
    MOV AH, 09H
    INT 21H

    ; 第二次比较：不同的字符串
    LEA SI, STRING1   ; SI 指向字符串1
    LEA DI, STRING2   ; DI 指向已修改的字符串2

    MOV CX, 25        ; 字符串长度为25

    ; 使用 REPE CMPSB 比较字符串
    REPE CMPSB        ; 当 CX != 0 且 ZF = 1 时重复比较

    ; 检查比较结果
    JNZ NOT_MATCH2    ; 如果 ZF = 0 (不相等)，跳转到 NOT_MATCH2

    ; 如果相等，显示 'Match'
    LEA DX, MSG_MATCH
    MOV AH, 09H
    INT 21H
    JMP DONE

NOT_MATCH2:
    ; 如果不相等，显示 'No match'
    LEA DX, MSG_NOMATCH
    MOV AH, 09H
    INT 21H

DONE:
    ; 程序结束
    MOV AH, 4CH
    INT 21H
MAIN ENDP
CODE ENDS
END MAIN