
target180/ctarget:     file format elf64-x86-64


Disassembly of section .init:

0000000000401000 <_init>:
  401000:	f3 0f 1e fa          	endbr64
  401004:	48 83 ec 08          	sub    $0x8,%rsp
  401008:	48 8b 05 e9 5f 00 00 	mov    0x5fe9(%rip),%rax        # 406ff8 <__gmon_start__>
  40100f:	48 85 c0             	test   %rax,%rax
  401012:	74 02                	je     401016 <_init+0x16>
  401014:	ff d0                	call   *%rax
  401016:	48 83 c4 08          	add    $0x8,%rsp
  40101a:	c3                   	ret

Disassembly of section .plt:

0000000000401020 <.plt>:
  401020:	ff 35 e2 5f 00 00    	push   0x5fe2(%rip)        # 407008 <_GLOBAL_OFFSET_TABLE_+0x8>
  401026:	f2 ff 25 e3 5f 00 00 	bnd jmp *0x5fe3(%rip)        # 407010 <_GLOBAL_OFFSET_TABLE_+0x10>
  40102d:	0f 1f 00             	nopl   (%rax)
  401030:	f3 0f 1e fa          	endbr64
  401034:	68 00 00 00 00       	push   $0x0
  401039:	f2 e9 e1 ff ff ff    	bnd jmp 401020 <.plt>
  40103f:	90                   	nop
  401040:	f3 0f 1e fa          	endbr64
  401044:	68 01 00 00 00       	push   $0x1
  401049:	f2 e9 d1 ff ff ff    	bnd jmp 401020 <.plt>
  40104f:	90                   	nop
  401050:	f3 0f 1e fa          	endbr64
  401054:	68 02 00 00 00       	push   $0x2
  401059:	f2 e9 c1 ff ff ff    	bnd jmp 401020 <.plt>
  40105f:	90                   	nop
  401060:	f3 0f 1e fa          	endbr64
  401064:	68 03 00 00 00       	push   $0x3
  401069:	f2 e9 b1 ff ff ff    	bnd jmp 401020 <.plt>
  40106f:	90                   	nop
  401070:	f3 0f 1e fa          	endbr64
  401074:	68 04 00 00 00       	push   $0x4
  401079:	f2 e9 a1 ff ff ff    	bnd jmp 401020 <.plt>
  40107f:	90                   	nop
  401080:	f3 0f 1e fa          	endbr64
  401084:	68 05 00 00 00       	push   $0x5
  401089:	f2 e9 91 ff ff ff    	bnd jmp 401020 <.plt>
  40108f:	90                   	nop
  401090:	f3 0f 1e fa          	endbr64
  401094:	68 06 00 00 00       	push   $0x6
  401099:	f2 e9 81 ff ff ff    	bnd jmp 401020 <.plt>
  40109f:	90                   	nop
  4010a0:	f3 0f 1e fa          	endbr64
  4010a4:	68 07 00 00 00       	push   $0x7
  4010a9:	f2 e9 71 ff ff ff    	bnd jmp 401020 <.plt>
  4010af:	90                   	nop
  4010b0:	f3 0f 1e fa          	endbr64
  4010b4:	68 08 00 00 00       	push   $0x8
  4010b9:	f2 e9 61 ff ff ff    	bnd jmp 401020 <.plt>
  4010bf:	90                   	nop
  4010c0:	f3 0f 1e fa          	endbr64
  4010c4:	68 09 00 00 00       	push   $0x9
  4010c9:	f2 e9 51 ff ff ff    	bnd jmp 401020 <.plt>
  4010cf:	90                   	nop
  4010d0:	f3 0f 1e fa          	endbr64
  4010d4:	68 0a 00 00 00       	push   $0xa
  4010d9:	f2 e9 41 ff ff ff    	bnd jmp 401020 <.plt>
  4010df:	90                   	nop
  4010e0:	f3 0f 1e fa          	endbr64
  4010e4:	68 0b 00 00 00       	push   $0xb
  4010e9:	f2 e9 31 ff ff ff    	bnd jmp 401020 <.plt>
  4010ef:	90                   	nop
  4010f0:	f3 0f 1e fa          	endbr64
  4010f4:	68 0c 00 00 00       	push   $0xc
  4010f9:	f2 e9 21 ff ff ff    	bnd jmp 401020 <.plt>
  4010ff:	90                   	nop
  401100:	f3 0f 1e fa          	endbr64
  401104:	68 0d 00 00 00       	push   $0xd
  401109:	f2 e9 11 ff ff ff    	bnd jmp 401020 <.plt>
  40110f:	90                   	nop
  401110:	f3 0f 1e fa          	endbr64
  401114:	68 0e 00 00 00       	push   $0xe
  401119:	f2 e9 01 ff ff ff    	bnd jmp 401020 <.plt>
  40111f:	90                   	nop
  401120:	f3 0f 1e fa          	endbr64
  401124:	68 0f 00 00 00       	push   $0xf
  401129:	f2 e9 f1 fe ff ff    	bnd jmp 401020 <.plt>
  40112f:	90                   	nop
  401130:	f3 0f 1e fa          	endbr64
  401134:	68 10 00 00 00       	push   $0x10
  401139:	f2 e9 e1 fe ff ff    	bnd jmp 401020 <.plt>
  40113f:	90                   	nop
  401140:	f3 0f 1e fa          	endbr64
  401144:	68 11 00 00 00       	push   $0x11
  401149:	f2 e9 d1 fe ff ff    	bnd jmp 401020 <.plt>
  40114f:	90                   	nop
  401150:	f3 0f 1e fa          	endbr64
  401154:	68 12 00 00 00       	push   $0x12
  401159:	f2 e9 c1 fe ff ff    	bnd jmp 401020 <.plt>
  40115f:	90                   	nop
  401160:	f3 0f 1e fa          	endbr64
  401164:	68 13 00 00 00       	push   $0x13
  401169:	f2 e9 b1 fe ff ff    	bnd jmp 401020 <.plt>
  40116f:	90                   	nop
  401170:	f3 0f 1e fa          	endbr64
  401174:	68 14 00 00 00       	push   $0x14
  401179:	f2 e9 a1 fe ff ff    	bnd jmp 401020 <.plt>
  40117f:	90                   	nop
  401180:	f3 0f 1e fa          	endbr64
  401184:	68 15 00 00 00       	push   $0x15
  401189:	f2 e9 91 fe ff ff    	bnd jmp 401020 <.plt>
  40118f:	90                   	nop
  401190:	f3 0f 1e fa          	endbr64
  401194:	68 16 00 00 00       	push   $0x16
  401199:	f2 e9 81 fe ff ff    	bnd jmp 401020 <.plt>
  40119f:	90                   	nop
  4011a0:	f3 0f 1e fa          	endbr64
  4011a4:	68 17 00 00 00       	push   $0x17
  4011a9:	f2 e9 71 fe ff ff    	bnd jmp 401020 <.plt>
  4011af:	90                   	nop
  4011b0:	f3 0f 1e fa          	endbr64
  4011b4:	68 18 00 00 00       	push   $0x18
  4011b9:	f2 e9 61 fe ff ff    	bnd jmp 401020 <.plt>
  4011bf:	90                   	nop
  4011c0:	f3 0f 1e fa          	endbr64
  4011c4:	68 19 00 00 00       	push   $0x19
  4011c9:	f2 e9 51 fe ff ff    	bnd jmp 401020 <.plt>
  4011cf:	90                   	nop
  4011d0:	f3 0f 1e fa          	endbr64
  4011d4:	68 1a 00 00 00       	push   $0x1a
  4011d9:	f2 e9 41 fe ff ff    	bnd jmp 401020 <.plt>
  4011df:	90                   	nop
  4011e0:	f3 0f 1e fa          	endbr64
  4011e4:	68 1b 00 00 00       	push   $0x1b
  4011e9:	f2 e9 31 fe ff ff    	bnd jmp 401020 <.plt>
  4011ef:	90                   	nop
  4011f0:	f3 0f 1e fa          	endbr64
  4011f4:	68 1c 00 00 00       	push   $0x1c
  4011f9:	f2 e9 21 fe ff ff    	bnd jmp 401020 <.plt>
  4011ff:	90                   	nop
  401200:	f3 0f 1e fa          	endbr64
  401204:	68 1d 00 00 00       	push   $0x1d
  401209:	f2 e9 11 fe ff ff    	bnd jmp 401020 <.plt>
  40120f:	90                   	nop
  401210:	f3 0f 1e fa          	endbr64
  401214:	68 1e 00 00 00       	push   $0x1e
  401219:	f2 e9 01 fe ff ff    	bnd jmp 401020 <.plt>
  40121f:	90                   	nop
  401220:	f3 0f 1e fa          	endbr64
  401224:	68 1f 00 00 00       	push   $0x1f
  401229:	f2 e9 f1 fd ff ff    	bnd jmp 401020 <.plt>
  40122f:	90                   	nop
  401230:	f3 0f 1e fa          	endbr64
  401234:	68 20 00 00 00       	push   $0x20
  401239:	f2 e9 e1 fd ff ff    	bnd jmp 401020 <.plt>
  40123f:	90                   	nop

Disassembly of section .plt.sec:

0000000000401240 <strcasecmp@plt>:
  401240:	f3 0f 1e fa          	endbr64
  401244:	f2 ff 25 cd 5d 00 00 	bnd jmp *0x5dcd(%rip)        # 407018 <strcasecmp@GLIBC_2.2.5>
  40124b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000401250 <__errno_location@plt>:
  401250:	f3 0f 1e fa          	endbr64
  401254:	f2 ff 25 c5 5d 00 00 	bnd jmp *0x5dc5(%rip)        # 407020 <__errno_location@GLIBC_2.2.5>
  40125b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000401260 <srandom@plt>:
  401260:	f3 0f 1e fa          	endbr64
  401264:	f2 ff 25 bd 5d 00 00 	bnd jmp *0x5dbd(%rip)        # 407028 <srandom@GLIBC_2.2.5>
  40126b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000401270 <strncmp@plt>:
  401270:	f3 0f 1e fa          	endbr64
  401274:	f2 ff 25 b5 5d 00 00 	bnd jmp *0x5db5(%rip)        # 407030 <strncmp@GLIBC_2.2.5>
  40127b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000401280 <strcpy@plt>:
  401280:	f3 0f 1e fa          	endbr64
  401284:	f2 ff 25 ad 5d 00 00 	bnd jmp *0x5dad(%rip)        # 407038 <strcpy@GLIBC_2.2.5>
  40128b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000401290 <puts@plt>:
  401290:	f3 0f 1e fa          	endbr64
  401294:	f2 ff 25 a5 5d 00 00 	bnd jmp *0x5da5(%rip)        # 407040 <puts@GLIBC_2.2.5>
  40129b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000004012a0 <write@plt>:
  4012a0:	f3 0f 1e fa          	endbr64
  4012a4:	f2 ff 25 9d 5d 00 00 	bnd jmp *0x5d9d(%rip)        # 407048 <write@GLIBC_2.2.5>
  4012ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000004012b0 <__stack_chk_fail@plt>:
  4012b0:	f3 0f 1e fa          	endbr64
  4012b4:	f2 ff 25 95 5d 00 00 	bnd jmp *0x5d95(%rip)        # 407050 <__stack_chk_fail@GLIBC_2.4>
  4012bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000004012c0 <mmap@plt>:
  4012c0:	f3 0f 1e fa          	endbr64
  4012c4:	f2 ff 25 8d 5d 00 00 	bnd jmp *0x5d8d(%rip)        # 407058 <mmap@GLIBC_2.2.5>
  4012cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000004012d0 <memset@plt>:
  4012d0:	f3 0f 1e fa          	endbr64
  4012d4:	f2 ff 25 85 5d 00 00 	bnd jmp *0x5d85(%rip)        # 407060 <memset@GLIBC_2.2.5>
  4012db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000004012e0 <alarm@plt>:
  4012e0:	f3 0f 1e fa          	endbr64
  4012e4:	f2 ff 25 7d 5d 00 00 	bnd jmp *0x5d7d(%rip)        # 407068 <alarm@GLIBC_2.2.5>
  4012eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000004012f0 <close@plt>:
  4012f0:	f3 0f 1e fa          	endbr64
  4012f4:	f2 ff 25 75 5d 00 00 	bnd jmp *0x5d75(%rip)        # 407070 <close@GLIBC_2.2.5>
  4012fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000401300 <read@plt>:
  401300:	f3 0f 1e fa          	endbr64
  401304:	f2 ff 25 6d 5d 00 00 	bnd jmp *0x5d6d(%rip)        # 407078 <read@GLIBC_2.2.5>
  40130b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000401310 <signal@plt>:
  401310:	f3 0f 1e fa          	endbr64
  401314:	f2 ff 25 65 5d 00 00 	bnd jmp *0x5d65(%rip)        # 407080 <signal@GLIBC_2.2.5>
  40131b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000401320 <gethostbyname@plt>:
  401320:	f3 0f 1e fa          	endbr64
  401324:	f2 ff 25 5d 5d 00 00 	bnd jmp *0x5d5d(%rip)        # 407088 <gethostbyname@GLIBC_2.2.5>
  40132b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000401330 <__memmove_chk@plt>:
  401330:	f3 0f 1e fa          	endbr64
  401334:	f2 ff 25 55 5d 00 00 	bnd jmp *0x5d55(%rip)        # 407090 <__memmove_chk@GLIBC_2.3.4>
  40133b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000401340 <strtol@plt>:
  401340:	f3 0f 1e fa          	endbr64
  401344:	f2 ff 25 4d 5d 00 00 	bnd jmp *0x5d4d(%rip)        # 407098 <strtol@GLIBC_2.2.5>
  40134b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000401350 <memcpy@plt>:
  401350:	f3 0f 1e fa          	endbr64
  401354:	f2 ff 25 45 5d 00 00 	bnd jmp *0x5d45(%rip)        # 4070a0 <memcpy@GLIBC_2.14>
  40135b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000401360 <time@plt>:
  401360:	f3 0f 1e fa          	endbr64
  401364:	f2 ff 25 3d 5d 00 00 	bnd jmp *0x5d3d(%rip)        # 4070a8 <time@GLIBC_2.2.5>
  40136b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000401370 <random@plt>:
  401370:	f3 0f 1e fa          	endbr64
  401374:	f2 ff 25 35 5d 00 00 	bnd jmp *0x5d35(%rip)        # 4070b0 <random@GLIBC_2.2.5>
  40137b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000401380 <__isoc99_sscanf@plt>:
  401380:	f3 0f 1e fa          	endbr64
  401384:	f2 ff 25 2d 5d 00 00 	bnd jmp *0x5d2d(%rip)        # 4070b8 <__isoc99_sscanf@GLIBC_2.7>
  40138b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000401390 <munmap@plt>:
  401390:	f3 0f 1e fa          	endbr64
  401394:	f2 ff 25 25 5d 00 00 	bnd jmp *0x5d25(%rip)        # 4070c0 <munmap@GLIBC_2.2.5>
  40139b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000004013a0 <__printf_chk@plt>:
  4013a0:	f3 0f 1e fa          	endbr64
  4013a4:	f2 ff 25 1d 5d 00 00 	bnd jmp *0x5d1d(%rip)        # 4070c8 <__printf_chk@GLIBC_2.3.4>
  4013ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000004013b0 <fopen@plt>:
  4013b0:	f3 0f 1e fa          	endbr64
  4013b4:	f2 ff 25 15 5d 00 00 	bnd jmp *0x5d15(%rip)        # 4070d0 <fopen@GLIBC_2.2.5>
  4013bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000004013c0 <getopt@plt>:
  4013c0:	f3 0f 1e fa          	endbr64
  4013c4:	f2 ff 25 0d 5d 00 00 	bnd jmp *0x5d0d(%rip)        # 4070d8 <getopt@GLIBC_2.2.5>
  4013cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000004013d0 <strtoul@plt>:
  4013d0:	f3 0f 1e fa          	endbr64
  4013d4:	f2 ff 25 05 5d 00 00 	bnd jmp *0x5d05(%rip)        # 4070e0 <strtoul@GLIBC_2.2.5>
  4013db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000004013e0 <gethostname@plt>:
  4013e0:	f3 0f 1e fa          	endbr64
  4013e4:	f2 ff 25 fd 5c 00 00 	bnd jmp *0x5cfd(%rip)        # 4070e8 <gethostname@GLIBC_2.2.5>
  4013eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000004013f0 <exit@plt>:
  4013f0:	f3 0f 1e fa          	endbr64
  4013f4:	f2 ff 25 f5 5c 00 00 	bnd jmp *0x5cf5(%rip)        # 4070f0 <exit@GLIBC_2.2.5>
  4013fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000401400 <connect@plt>:
  401400:	f3 0f 1e fa          	endbr64
  401404:	f2 ff 25 ed 5c 00 00 	bnd jmp *0x5ced(%rip)        # 4070f8 <connect@GLIBC_2.2.5>
  40140b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000401410 <__fprintf_chk@plt>:
  401410:	f3 0f 1e fa          	endbr64
  401414:	f2 ff 25 e5 5c 00 00 	bnd jmp *0x5ce5(%rip)        # 407100 <__fprintf_chk@GLIBC_2.3.4>
  40141b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000401420 <getc@plt>:
  401420:	f3 0f 1e fa          	endbr64
  401424:	f2 ff 25 dd 5c 00 00 	bnd jmp *0x5cdd(%rip)        # 407108 <getc@GLIBC_2.2.5>
  40142b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000401430 <__sprintf_chk@plt>:
  401430:	f3 0f 1e fa          	endbr64
  401434:	f2 ff 25 d5 5c 00 00 	bnd jmp *0x5cd5(%rip)        # 407110 <__sprintf_chk@GLIBC_2.3.4>
  40143b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000401440 <socket@plt>:
  401440:	f3 0f 1e fa          	endbr64
  401444:	f2 ff 25 cd 5c 00 00 	bnd jmp *0x5ccd(%rip)        # 407118 <socket@GLIBC_2.2.5>
  40144b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000401450 <_start>:
  401450:	f3 0f 1e fa          	endbr64
  401454:	31 ed                	xor    %ebp,%ebp
  401456:	49 89 d1             	mov    %rdx,%r9
  401459:	5e                   	pop    %rsi
  40145a:	48 89 e2             	mov    %rsp,%rdx
  40145d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
  401461:	50                   	push   %rax
  401462:	54                   	push   %rsp
  401463:	49 c7 c0 30 36 40 00 	mov    $0x403630,%r8
  40146a:	48 c7 c1 c0 35 40 00 	mov    $0x4035c0,%rcx
  401471:	48 c7 c7 79 17 40 00 	mov    $0x401779,%rdi
  401478:	ff 15 72 5b 00 00    	call   *0x5b72(%rip)        # 406ff0 <__libc_start_main@GLIBC_2.2.5>
  40147e:	f4                   	hlt
  40147f:	90                   	nop

0000000000401480 <_dl_relocate_static_pie>:
  401480:	f3 0f 1e fa          	endbr64
  401484:	c3                   	ret
  401485:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  40148c:	00 00 00 
  40148f:	90                   	nop

0000000000401490 <deregister_tm_clones>:
  401490:	b8 90 74 40 00       	mov    $0x407490,%eax
  401495:	48 3d 90 74 40 00    	cmp    $0x407490,%rax
  40149b:	74 13                	je     4014b0 <deregister_tm_clones+0x20>
  40149d:	b8 00 00 00 00       	mov    $0x0,%eax
  4014a2:	48 85 c0             	test   %rax,%rax
  4014a5:	74 09                	je     4014b0 <deregister_tm_clones+0x20>
  4014a7:	bf 90 74 40 00       	mov    $0x407490,%edi
  4014ac:	ff e0                	jmp    *%rax
  4014ae:	66 90                	xchg   %ax,%ax
  4014b0:	c3                   	ret
  4014b1:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  4014b8:	00 00 00 00 
  4014bc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000004014c0 <register_tm_clones>:
  4014c0:	be 90 74 40 00       	mov    $0x407490,%esi
  4014c5:	48 81 ee 90 74 40 00 	sub    $0x407490,%rsi
  4014cc:	48 89 f0             	mov    %rsi,%rax
  4014cf:	48 c1 ee 3f          	shr    $0x3f,%rsi
  4014d3:	48 c1 f8 03          	sar    $0x3,%rax
  4014d7:	48 01 c6             	add    %rax,%rsi
  4014da:	48 d1 fe             	sar    $1,%rsi
  4014dd:	74 11                	je     4014f0 <register_tm_clones+0x30>
  4014df:	b8 00 00 00 00       	mov    $0x0,%eax
  4014e4:	48 85 c0             	test   %rax,%rax
  4014e7:	74 07                	je     4014f0 <register_tm_clones+0x30>
  4014e9:	bf 90 74 40 00       	mov    $0x407490,%edi
  4014ee:	ff e0                	jmp    *%rax
  4014f0:	c3                   	ret
  4014f1:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  4014f8:	00 00 00 00 
  4014fc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000401500 <__do_global_dtors_aux>:
  401500:	f3 0f 1e fa          	endbr64
  401504:	80 3d bd 5f 00 00 00 	cmpb   $0x0,0x5fbd(%rip)        # 4074c8 <completed.8061>
  40150b:	75 13                	jne    401520 <__do_global_dtors_aux+0x20>
  40150d:	55                   	push   %rbp
  40150e:	48 89 e5             	mov    %rsp,%rbp
  401511:	e8 7a ff ff ff       	call   401490 <deregister_tm_clones>
  401516:	c6 05 ab 5f 00 00 01 	movb   $0x1,0x5fab(%rip)        # 4074c8 <completed.8061>
  40151d:	5d                   	pop    %rbp
  40151e:	c3                   	ret
  40151f:	90                   	nop
  401520:	c3                   	ret
  401521:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  401528:	00 00 00 00 
  40152c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000401530 <frame_dummy>:
  401530:	f3 0f 1e fa          	endbr64
  401534:	eb 8a                	jmp    4014c0 <register_tm_clones>

0000000000401536 <usage>:
  401536:	50                   	push   %rax
  401537:	58                   	pop    %rax
  401538:	48 83 ec 08          	sub    $0x8,%rsp
  40153c:	48 89 fa             	mov    %rdi,%rdx
  40153f:	83 3d c2 5f 00 00 00 	cmpl   $0x0,0x5fc2(%rip)        # 407508 <is_checker>
  401546:	74 50                	je     401598 <usage+0x62>
  401548:	48 8d 35 b9 2a 00 00 	lea    0x2ab9(%rip),%rsi        # 404008 <_IO_stdin_used+0x8>
  40154f:	bf 01 00 00 00       	mov    $0x1,%edi
  401554:	b8 00 00 00 00       	mov    $0x0,%eax
  401559:	e8 42 fe ff ff       	call   4013a0 <__printf_chk@plt>
  40155e:	48 8d 3d db 2a 00 00 	lea    0x2adb(%rip),%rdi        # 404040 <_IO_stdin_used+0x40>
  401565:	e8 26 fd ff ff       	call   401290 <puts@plt>
  40156a:	48 8d 3d 47 2c 00 00 	lea    0x2c47(%rip),%rdi        # 4041b8 <_IO_stdin_used+0x1b8>
  401571:	e8 1a fd ff ff       	call   401290 <puts@plt>
  401576:	48 8d 3d eb 2a 00 00 	lea    0x2aeb(%rip),%rdi        # 404068 <_IO_stdin_used+0x68>
  40157d:	e8 0e fd ff ff       	call   401290 <puts@plt>
  401582:	48 8d 3d 49 2c 00 00 	lea    0x2c49(%rip),%rdi        # 4041d2 <_IO_stdin_used+0x1d2>
  401589:	e8 02 fd ff ff       	call   401290 <puts@plt>
  40158e:	bf 00 00 00 00       	mov    $0x0,%edi
  401593:	e8 58 fe ff ff       	call   4013f0 <exit@plt>
  401598:	48 8d 35 4f 2c 00 00 	lea    0x2c4f(%rip),%rsi        # 4041ee <_IO_stdin_used+0x1ee>
  40159f:	bf 01 00 00 00       	mov    $0x1,%edi
  4015a4:	b8 00 00 00 00       	mov    $0x0,%eax
  4015a9:	e8 f2 fd ff ff       	call   4013a0 <__printf_chk@plt>
  4015ae:	48 8d 3d db 2a 00 00 	lea    0x2adb(%rip),%rdi        # 404090 <_IO_stdin_used+0x90>
  4015b5:	e8 d6 fc ff ff       	call   401290 <puts@plt>
  4015ba:	48 8d 3d f7 2a 00 00 	lea    0x2af7(%rip),%rdi        # 4040b8 <_IO_stdin_used+0xb8>
  4015c1:	e8 ca fc ff ff       	call   401290 <puts@plt>
  4015c6:	48 8d 3d 3f 2c 00 00 	lea    0x2c3f(%rip),%rdi        # 40420c <_IO_stdin_used+0x20c>
  4015cd:	e8 be fc ff ff       	call   401290 <puts@plt>
  4015d2:	eb ba                	jmp    40158e <usage+0x58>

00000000004015d4 <initialize_target>:
  4015d4:	55                   	push   %rbp
  4015d5:	53                   	push   %rbx
  4015d6:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
  4015dd:	48 83 0c 24 00       	orq    $0x0,(%rsp)
  4015e2:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
  4015e9:	48 83 0c 24 00       	orq    $0x0,(%rsp)
  4015ee:	48 81 ec 18 01 00 00 	sub    $0x118,%rsp
  4015f5:	89 f5                	mov    %esi,%ebp
  4015f7:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
  4015fe:	00 00 
  401600:	48 89 84 24 08 21 00 	mov    %rax,0x2108(%rsp)
  401607:	00 
  401608:	31 c0                	xor    %eax,%eax
  40160a:	89 3d e8 5e 00 00    	mov    %edi,0x5ee8(%rip)        # 4074f8 <check_level>
  401610:	8b 3d 1a 5b 00 00    	mov    0x5b1a(%rip),%edi        # 407130 <target_id>
  401616:	e8 72 1f 00 00       	call   40358d <gencookie>
  40161b:	89 c7                	mov    %eax,%edi
  40161d:	89 05 e1 5e 00 00    	mov    %eax,0x5ee1(%rip)        # 407504 <cookie>
  401623:	e8 65 1f 00 00       	call   40358d <gencookie>
  401628:	89 05 d2 5e 00 00    	mov    %eax,0x5ed2(%rip)        # 407500 <authkey>
  40162e:	8b 05 fc 5a 00 00    	mov    0x5afc(%rip),%eax        # 407130 <target_id>
  401634:	8d 78 01             	lea    0x1(%rax),%edi
  401637:	e8 24 fc ff ff       	call   401260 <srandom@plt>
  40163c:	e8 2f fd ff ff       	call   401370 <random@plt>
  401641:	48 89 c7             	mov    %rax,%rdi
  401644:	e8 20 03 00 00       	call   401969 <scramble>
  401649:	89 c3                	mov    %eax,%ebx
  40164b:	85 ed                	test   %ebp,%ebp
  40164d:	75 54                	jne    4016a3 <initialize_target+0xcf>
  40164f:	b8 00 00 00 00       	mov    $0x0,%eax
  401654:	01 d8                	add    %ebx,%eax
  401656:	0f b7 c0             	movzwl %ax,%eax
  401659:	8d 04 c5 00 01 00 00 	lea    0x100(,%rax,8),%eax
  401660:	89 c0                	mov    %eax,%eax
  401662:	48 89 05 17 5e 00 00 	mov    %rax,0x5e17(%rip)        # 407480 <buf_offset>
  401669:	c6 05 b8 6a 00 00 63 	movb   $0x63,0x6ab8(%rip)        # 408128 <target_prefix>
  401670:	83 3d 11 5e 00 00 00 	cmpl   $0x0,0x5e11(%rip)        # 407488 <notify>
  401677:	74 09                	je     401682 <initialize_target+0xae>
  401679:	83 3d 88 5e 00 00 00 	cmpl   $0x0,0x5e88(%rip)        # 407508 <is_checker>
  401680:	74 3a                	je     4016bc <initialize_target+0xe8>
  401682:	48 8b 84 24 08 21 00 	mov    0x2108(%rsp),%rax
  401689:	00 
  40168a:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
  401691:	00 00 
  401693:	0f 85 db 00 00 00    	jne    401774 <initialize_target+0x1a0>
  401699:	48 81 c4 18 21 00 00 	add    $0x2118,%rsp
  4016a0:	5b                   	pop    %rbx
  4016a1:	5d                   	pop    %rbp
  4016a2:	c3                   	ret
  4016a3:	bf 00 00 00 00       	mov    $0x0,%edi
  4016a8:	e8 b3 fc ff ff       	call   401360 <time@plt>
  4016ad:	48 89 c7             	mov    %rax,%rdi
  4016b0:	e8 ab fb ff ff       	call   401260 <srandom@plt>
  4016b5:	e8 b6 fc ff ff       	call   401370 <random@plt>
  4016ba:	eb 98                	jmp    401654 <initialize_target+0x80>
  4016bc:	48 89 e7             	mov    %rsp,%rdi
  4016bf:	be 00 01 00 00       	mov    $0x100,%esi
  4016c4:	e8 17 fd ff ff       	call   4013e0 <gethostname@plt>
  4016c9:	89 c5                	mov    %eax,%ebp
  4016cb:	85 c0                	test   %eax,%eax
  4016cd:	75 26                	jne    4016f5 <initialize_target+0x121>
  4016cf:	89 c3                	mov    %eax,%ebx
  4016d1:	48 63 c3             	movslq %ebx,%rax
  4016d4:	48 8d 15 85 5a 00 00 	lea    0x5a85(%rip),%rdx        # 407160 <host_table>
  4016db:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
  4016df:	48 85 ff             	test   %rdi,%rdi
  4016e2:	74 2c                	je     401710 <initialize_target+0x13c>
  4016e4:	48 89 e6             	mov    %rsp,%rsi
  4016e7:	e8 54 fb ff ff       	call   401240 <strcasecmp@plt>
  4016ec:	85 c0                	test   %eax,%eax
  4016ee:	74 1b                	je     40170b <initialize_target+0x137>
  4016f0:	83 c3 01             	add    $0x1,%ebx
  4016f3:	eb dc                	jmp    4016d1 <initialize_target+0xfd>
  4016f5:	48 8d 3d ec 29 00 00 	lea    0x29ec(%rip),%rdi        # 4040e8 <_IO_stdin_used+0xe8>
  4016fc:	e8 8f fb ff ff       	call   401290 <puts@plt>
  401701:	bf 08 00 00 00       	mov    $0x8,%edi
  401706:	e8 e5 fc ff ff       	call   4013f0 <exit@plt>
  40170b:	bd 01 00 00 00       	mov    $0x1,%ebp
  401710:	85 ed                	test   %ebp,%ebp
  401712:	74 3d                	je     401751 <initialize_target+0x17d>
  401714:	48 8d bc 24 00 01 00 	lea    0x100(%rsp),%rdi
  40171b:	00 
  40171c:	e8 b1 1b 00 00       	call   4032d2 <init_driver>
  401721:	85 c0                	test   %eax,%eax
  401723:	0f 89 59 ff ff ff    	jns    401682 <initialize_target+0xae>
  401729:	48 8d 94 24 00 01 00 	lea    0x100(%rsp),%rdx
  401730:	00 
  401731:	48 8d 35 28 2a 00 00 	lea    0x2a28(%rip),%rsi        # 404160 <_IO_stdin_used+0x160>
  401738:	bf 01 00 00 00       	mov    $0x1,%edi
  40173d:	b8 00 00 00 00       	mov    $0x0,%eax
  401742:	e8 59 fc ff ff       	call   4013a0 <__printf_chk@plt>
  401747:	bf 08 00 00 00       	mov    $0x8,%edi
  40174c:	e8 9f fc ff ff       	call   4013f0 <exit@plt>
  401751:	48 89 e2             	mov    %rsp,%rdx
  401754:	48 8d 35 c5 29 00 00 	lea    0x29c5(%rip),%rsi        # 404120 <_IO_stdin_used+0x120>
  40175b:	bf 01 00 00 00       	mov    $0x1,%edi
  401760:	b8 00 00 00 00       	mov    $0x0,%eax
  401765:	e8 36 fc ff ff       	call   4013a0 <__printf_chk@plt>
  40176a:	bf 08 00 00 00       	mov    $0x8,%edi
  40176f:	e8 7c fc ff ff       	call   4013f0 <exit@plt>
  401774:	e8 37 fb ff ff       	call   4012b0 <__stack_chk_fail@plt>

0000000000401779 <main>:
  401779:	f3 0f 1e fa          	endbr64
  40177d:	41 56                	push   %r14
  40177f:	41 55                	push   %r13
  401781:	41 54                	push   %r12
  401783:	55                   	push   %rbp
  401784:	53                   	push   %rbx
  401785:	89 fd                	mov    %edi,%ebp
  401787:	48 89 f3             	mov    %rsi,%rbx
  40178a:	48 c7 c6 75 25 40 00 	mov    $0x402575,%rsi
  401791:	bf 0b 00 00 00       	mov    $0xb,%edi
  401796:	e8 75 fb ff ff       	call   401310 <signal@plt>
  40179b:	48 c7 c6 1b 25 40 00 	mov    $0x40251b,%rsi
  4017a2:	bf 07 00 00 00       	mov    $0x7,%edi
  4017a7:	e8 64 fb ff ff       	call   401310 <signal@plt>
  4017ac:	48 c7 c6 cf 25 40 00 	mov    $0x4025cf,%rsi
  4017b3:	bf 04 00 00 00       	mov    $0x4,%edi
  4017b8:	e8 53 fb ff ff       	call   401310 <signal@plt>
  4017bd:	83 3d 44 5d 00 00 00 	cmpl   $0x0,0x5d44(%rip)        # 407508 <is_checker>
  4017c4:	75 26                	jne    4017ec <main+0x73>
  4017c6:	4c 8d 25 60 2a 00 00 	lea    0x2a60(%rip),%r12        # 40422d <_IO_stdin_used+0x22d>
  4017cd:	48 8b 05 cc 5c 00 00 	mov    0x5ccc(%rip),%rax        # 4074a0 <stdin@GLIBC_2.2.5>
  4017d4:	48 89 05 15 5d 00 00 	mov    %rax,0x5d15(%rip)        # 4074f0 <infile>
  4017db:	41 bd 00 00 00 00    	mov    $0x0,%r13d
  4017e1:	41 be 00 00 00 00    	mov    $0x0,%r14d
  4017e7:	e9 8d 00 00 00       	jmp    401879 <main+0x100>
  4017ec:	48 c7 c6 29 26 40 00 	mov    $0x402629,%rsi
  4017f3:	bf 0e 00 00 00       	mov    $0xe,%edi
  4017f8:	e8 13 fb ff ff       	call   401310 <signal@plt>
  4017fd:	bf 05 00 00 00       	mov    $0x5,%edi
  401802:	e8 d9 fa ff ff       	call   4012e0 <alarm@plt>
  401807:	4c 8d 25 17 2a 00 00 	lea    0x2a17(%rip),%r12        # 404225 <_IO_stdin_used+0x225>
  40180e:	eb bd                	jmp    4017cd <main+0x54>
  401810:	48 8b 3b             	mov    (%rbx),%rdi
  401813:	e8 1e fd ff ff       	call   401536 <usage>
  401818:	48 8d 35 d5 2a 00 00 	lea    0x2ad5(%rip),%rsi        # 4042f4 <_IO_stdin_used+0x2f4>
  40181f:	48 8b 3d 82 5c 00 00 	mov    0x5c82(%rip),%rdi        # 4074a8 <optarg@GLIBC_2.2.5>
  401826:	e8 85 fb ff ff       	call   4013b0 <fopen@plt>
  40182b:	48 89 05 be 5c 00 00 	mov    %rax,0x5cbe(%rip)        # 4074f0 <infile>
  401832:	48 85 c0             	test   %rax,%rax
  401835:	75 42                	jne    401879 <main+0x100>
  401837:	48 8b 0d 6a 5c 00 00 	mov    0x5c6a(%rip),%rcx        # 4074a8 <optarg@GLIBC_2.2.5>
  40183e:	48 8d 15 ed 29 00 00 	lea    0x29ed(%rip),%rdx        # 404232 <_IO_stdin_used+0x232>
  401845:	be 01 00 00 00       	mov    $0x1,%esi
  40184a:	48 8b 3d 6f 5c 00 00 	mov    0x5c6f(%rip),%rdi        # 4074c0 <stderr@GLIBC_2.2.5>
  401851:	e8 ba fb ff ff       	call   401410 <__fprintf_chk@plt>
  401856:	b8 01 00 00 00       	mov    $0x1,%eax
  40185b:	e9 db 00 00 00       	jmp    40193b <main+0x1c2>
  401860:	ba 10 00 00 00       	mov    $0x10,%edx
  401865:	be 00 00 00 00       	mov    $0x0,%esi
  40186a:	48 8b 3d 37 5c 00 00 	mov    0x5c37(%rip),%rdi        # 4074a8 <optarg@GLIBC_2.2.5>
  401871:	e8 5a fb ff ff       	call   4013d0 <strtoul@plt>
  401876:	41 89 c6             	mov    %eax,%r14d
  401879:	4c 89 e2             	mov    %r12,%rdx
  40187c:	48 89 de             	mov    %rbx,%rsi
  40187f:	89 ef                	mov    %ebp,%edi
  401881:	e8 3a fb ff ff       	call   4013c0 <getopt@plt>
  401886:	3c ff                	cmp    $0xff,%al
  401888:	74 65                	je     4018ef <main+0x176>
  40188a:	0f be c8             	movsbl %al,%ecx
  40188d:	83 e8 61             	sub    $0x61,%eax
  401890:	3c 10                	cmp    $0x10,%al
  401892:	77 3b                	ja     4018cf <main+0x156>
  401894:	0f b6 c0             	movzbl %al,%eax
  401897:	48 8d 15 d2 29 00 00 	lea    0x29d2(%rip),%rdx        # 404270 <_IO_stdin_used+0x270>
  40189e:	48 63 04 82          	movslq (%rdx,%rax,4),%rax
  4018a2:	48 01 d0             	add    %rdx,%rax
  4018a5:	3e ff e0             	notrack jmp *%rax
  4018a8:	ba 0a 00 00 00       	mov    $0xa,%edx
  4018ad:	be 00 00 00 00       	mov    $0x0,%esi
  4018b2:	48 8b 3d ef 5b 00 00 	mov    0x5bef(%rip),%rdi        # 4074a8 <optarg@GLIBC_2.2.5>
  4018b9:	e8 82 fa ff ff       	call   401340 <strtol@plt>
  4018be:	41 89 c5             	mov    %eax,%r13d
  4018c1:	eb b6                	jmp    401879 <main+0x100>
  4018c3:	c7 05 bb 5b 00 00 00 	movl   $0x0,0x5bbb(%rip)        # 407488 <notify>
  4018ca:	00 00 00 
  4018cd:	eb aa                	jmp    401879 <main+0x100>
  4018cf:	89 ca                	mov    %ecx,%edx
  4018d1:	48 8d 35 77 29 00 00 	lea    0x2977(%rip),%rsi        # 40424f <_IO_stdin_used+0x24f>
  4018d8:	bf 01 00 00 00       	mov    $0x1,%edi
  4018dd:	b8 00 00 00 00       	mov    $0x0,%eax
  4018e2:	e8 b9 fa ff ff       	call   4013a0 <__printf_chk@plt>
  4018e7:	48 8b 3b             	mov    (%rbx),%rdi
  4018ea:	e8 47 fc ff ff       	call   401536 <usage>
  4018ef:	be 00 00 00 00       	mov    $0x0,%esi
  4018f4:	44 89 ef             	mov    %r13d,%edi
  4018f7:	e8 d8 fc ff ff       	call   4015d4 <initialize_target>
  4018fc:	83 3d 05 5c 00 00 00 	cmpl   $0x0,0x5c05(%rip)        # 407508 <is_checker>
  401903:	74 09                	je     40190e <main+0x195>
  401905:	44 39 35 f4 5b 00 00 	cmp    %r14d,0x5bf4(%rip)        # 407500 <authkey>
  40190c:	75 36                	jne    401944 <main+0x1cb>
  40190e:	8b 15 f0 5b 00 00    	mov    0x5bf0(%rip),%edx        # 407504 <cookie>
  401914:	48 8d 35 47 29 00 00 	lea    0x2947(%rip),%rsi        # 404262 <_IO_stdin_used+0x262>
  40191b:	bf 01 00 00 00       	mov    $0x1,%edi
  401920:	b8 00 00 00 00       	mov    $0x0,%eax
  401925:	e8 76 fa ff ff       	call   4013a0 <__printf_chk@plt>
  40192a:	48 8b 3d 4f 5b 00 00 	mov    0x5b4f(%rip),%rdi        # 407480 <buf_offset>
  401931:	e8 45 0e 00 00       	call   40277b <stable_launch>
  401936:	b8 00 00 00 00       	mov    $0x0,%eax
  40193b:	5b                   	pop    %rbx
  40193c:	5d                   	pop    %rbp
  40193d:	41 5c                	pop    %r12
  40193f:	41 5d                	pop    %r13
  401941:	41 5e                	pop    %r14
  401943:	c3                   	ret
  401944:	44 89 f2             	mov    %r14d,%edx
  401947:	48 8d 35 3a 28 00 00 	lea    0x283a(%rip),%rsi        # 404188 <_IO_stdin_used+0x188>
  40194e:	bf 01 00 00 00       	mov    $0x1,%edi
  401953:	b8 00 00 00 00       	mov    $0x0,%eax
  401958:	e8 43 fa ff ff       	call   4013a0 <__printf_chk@plt>
  40195d:	b8 00 00 00 00       	mov    $0x0,%eax
  401962:	e8 03 08 00 00       	call   40216a <check_fail>
  401967:	eb a5                	jmp    40190e <main+0x195>

0000000000401969 <scramble>:
  401969:	f3 0f 1e fa          	endbr64
  40196d:	48 83 ec 38          	sub    $0x38,%rsp
  401971:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
  401978:	00 00 
  40197a:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  40197f:	31 c0                	xor    %eax,%eax
  401981:	83 f8 09             	cmp    $0x9,%eax
  401984:	77 12                	ja     401998 <scramble+0x2f>
  401986:	69 d0 06 53 00 00    	imul   $0x5306,%eax,%edx
  40198c:	01 fa                	add    %edi,%edx
  40198e:	89 c1                	mov    %eax,%ecx
  401990:	89 14 8c             	mov    %edx,(%rsp,%rcx,4)
  401993:	83 c0 01             	add    $0x1,%eax
  401996:	eb e9                	jmp    401981 <scramble+0x18>
  401998:	8b 44 24 10          	mov    0x10(%rsp),%eax
  40199c:	69 c0 00 e9 00 00    	imul   $0xe900,%eax,%eax
  4019a2:	89 44 24 10          	mov    %eax,0x10(%rsp)
  4019a6:	8b 44 24 14          	mov    0x14(%rsp),%eax
  4019aa:	69 c0 7d 8d 00 00    	imul   $0x8d7d,%eax,%eax
  4019b0:	89 44 24 14          	mov    %eax,0x14(%rsp)
  4019b4:	8b 44 24 14          	mov    0x14(%rsp),%eax
  4019b8:	69 c0 6a 1b 00 00    	imul   $0x1b6a,%eax,%eax
  4019be:	89 44 24 14          	mov    %eax,0x14(%rsp)
  4019c2:	8b 44 24 10          	mov    0x10(%rsp),%eax
  4019c6:	69 c0 fa d3 00 00    	imul   $0xd3fa,%eax,%eax
  4019cc:	89 44 24 10          	mov    %eax,0x10(%rsp)
  4019d0:	8b 44 24 20          	mov    0x20(%rsp),%eax
  4019d4:	69 c0 48 9d 00 00    	imul   $0x9d48,%eax,%eax
  4019da:	89 44 24 20          	mov    %eax,0x20(%rsp)
  4019de:	8b 04 24             	mov    (%rsp),%eax
  4019e1:	69 c0 25 9b 00 00    	imul   $0x9b25,%eax,%eax
  4019e7:	89 04 24             	mov    %eax,(%rsp)
  4019ea:	8b 04 24             	mov    (%rsp),%eax
  4019ed:	69 c0 54 1d 00 00    	imul   $0x1d54,%eax,%eax
  4019f3:	89 04 24             	mov    %eax,(%rsp)
  4019f6:	8b 44 24 1c          	mov    0x1c(%rsp),%eax
  4019fa:	69 c0 1b 0c 00 00    	imul   $0xc1b,%eax,%eax
  401a00:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
  401a04:	8b 44 24 14          	mov    0x14(%rsp),%eax
  401a08:	69 c0 82 c7 00 00    	imul   $0xc782,%eax,%eax
  401a0e:	89 44 24 14          	mov    %eax,0x14(%rsp)
  401a12:	8b 44 24 14          	mov    0x14(%rsp),%eax
  401a16:	69 c0 01 ef 00 00    	imul   $0xef01,%eax,%eax
  401a1c:	89 44 24 14          	mov    %eax,0x14(%rsp)
  401a20:	8b 04 24             	mov    (%rsp),%eax
  401a23:	69 c0 a3 cc 00 00    	imul   $0xcca3,%eax,%eax
  401a29:	89 04 24             	mov    %eax,(%rsp)
  401a2c:	8b 44 24 04          	mov    0x4(%rsp),%eax
  401a30:	69 c0 5a 8a 00 00    	imul   $0x8a5a,%eax,%eax
  401a36:	89 44 24 04          	mov    %eax,0x4(%rsp)
  401a3a:	8b 44 24 0c          	mov    0xc(%rsp),%eax
  401a3e:	69 c0 78 52 00 00    	imul   $0x5278,%eax,%eax
  401a44:	89 44 24 0c          	mov    %eax,0xc(%rsp)
  401a48:	8b 44 24 0c          	mov    0xc(%rsp),%eax
  401a4c:	69 c0 eb a9 00 00    	imul   $0xa9eb,%eax,%eax
  401a52:	89 44 24 0c          	mov    %eax,0xc(%rsp)
  401a56:	8b 44 24 20          	mov    0x20(%rsp),%eax
  401a5a:	69 c0 d0 08 00 00    	imul   $0x8d0,%eax,%eax
  401a60:	89 44 24 20          	mov    %eax,0x20(%rsp)
  401a64:	8b 44 24 20          	mov    0x20(%rsp),%eax
  401a68:	69 c0 e1 e0 00 00    	imul   $0xe0e1,%eax,%eax
  401a6e:	89 44 24 20          	mov    %eax,0x20(%rsp)
  401a72:	8b 44 24 1c          	mov    0x1c(%rsp),%eax
  401a76:	69 c0 0f 65 00 00    	imul   $0x650f,%eax,%eax
  401a7c:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
  401a80:	8b 44 24 24          	mov    0x24(%rsp),%eax
  401a84:	69 c0 a2 0f 00 00    	imul   $0xfa2,%eax,%eax
  401a8a:	89 44 24 24          	mov    %eax,0x24(%rsp)
  401a8e:	8b 44 24 08          	mov    0x8(%rsp),%eax
  401a92:	69 c0 02 78 00 00    	imul   $0x7802,%eax,%eax
  401a98:	89 44 24 08          	mov    %eax,0x8(%rsp)
  401a9c:	8b 44 24 10          	mov    0x10(%rsp),%eax
  401aa0:	69 c0 c6 4c 00 00    	imul   $0x4cc6,%eax,%eax
  401aa6:	89 44 24 10          	mov    %eax,0x10(%rsp)
  401aaa:	8b 44 24 24          	mov    0x24(%rsp),%eax
  401aae:	69 c0 ea 0f 00 00    	imul   $0xfea,%eax,%eax
  401ab4:	89 44 24 24          	mov    %eax,0x24(%rsp)
  401ab8:	8b 44 24 08          	mov    0x8(%rsp),%eax
  401abc:	69 c0 36 98 00 00    	imul   $0x9836,%eax,%eax
  401ac2:	89 44 24 08          	mov    %eax,0x8(%rsp)
  401ac6:	8b 44 24 24          	mov    0x24(%rsp),%eax
  401aca:	69 c0 85 0c 00 00    	imul   $0xc85,%eax,%eax
  401ad0:	89 44 24 24          	mov    %eax,0x24(%rsp)
  401ad4:	8b 44 24 24          	mov    0x24(%rsp),%eax
  401ad8:	69 c0 3b a9 00 00    	imul   $0xa93b,%eax,%eax
  401ade:	89 44 24 24          	mov    %eax,0x24(%rsp)
  401ae2:	8b 44 24 20          	mov    0x20(%rsp),%eax
  401ae6:	69 c0 44 22 00 00    	imul   $0x2244,%eax,%eax
  401aec:	89 44 24 20          	mov    %eax,0x20(%rsp)
  401af0:	8b 44 24 10          	mov    0x10(%rsp),%eax
  401af4:	69 c0 f6 6a 00 00    	imul   $0x6af6,%eax,%eax
  401afa:	89 44 24 10          	mov    %eax,0x10(%rsp)
  401afe:	8b 44 24 14          	mov    0x14(%rsp),%eax
  401b02:	69 c0 d0 9c 00 00    	imul   $0x9cd0,%eax,%eax
  401b08:	89 44 24 14          	mov    %eax,0x14(%rsp)
  401b0c:	8b 44 24 04          	mov    0x4(%rsp),%eax
  401b10:	69 c0 19 d3 00 00    	imul   $0xd319,%eax,%eax
  401b16:	89 44 24 04          	mov    %eax,0x4(%rsp)
  401b1a:	8b 44 24 20          	mov    0x20(%rsp),%eax
  401b1e:	69 c0 c2 13 00 00    	imul   $0x13c2,%eax,%eax
  401b24:	89 44 24 20          	mov    %eax,0x20(%rsp)
  401b28:	8b 44 24 14          	mov    0x14(%rsp),%eax
  401b2c:	69 c0 24 7d 00 00    	imul   $0x7d24,%eax,%eax
  401b32:	89 44 24 14          	mov    %eax,0x14(%rsp)
  401b36:	8b 44 24 18          	mov    0x18(%rsp),%eax
  401b3a:	69 c0 66 14 00 00    	imul   $0x1466,%eax,%eax
  401b40:	89 44 24 18          	mov    %eax,0x18(%rsp)
  401b44:	8b 44 24 04          	mov    0x4(%rsp),%eax
  401b48:	69 c0 63 0e 00 00    	imul   $0xe63,%eax,%eax
  401b4e:	89 44 24 04          	mov    %eax,0x4(%rsp)
  401b52:	8b 44 24 04          	mov    0x4(%rsp),%eax
  401b56:	69 c0 65 cc 00 00    	imul   $0xcc65,%eax,%eax
  401b5c:	89 44 24 04          	mov    %eax,0x4(%rsp)
  401b60:	8b 44 24 1c          	mov    0x1c(%rsp),%eax
  401b64:	69 c0 ef f9 00 00    	imul   $0xf9ef,%eax,%eax
  401b6a:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
  401b6e:	8b 44 24 24          	mov    0x24(%rsp),%eax
  401b72:	69 c0 a1 01 00 00    	imul   $0x1a1,%eax,%eax
  401b78:	89 44 24 24          	mov    %eax,0x24(%rsp)
  401b7c:	8b 44 24 14          	mov    0x14(%rsp),%eax
  401b80:	69 c0 b2 59 00 00    	imul   $0x59b2,%eax,%eax
  401b86:	89 44 24 14          	mov    %eax,0x14(%rsp)
  401b8a:	8b 44 24 20          	mov    0x20(%rsp),%eax
  401b8e:	69 c0 a0 2e 00 00    	imul   $0x2ea0,%eax,%eax
  401b94:	89 44 24 20          	mov    %eax,0x20(%rsp)
  401b98:	8b 44 24 04          	mov    0x4(%rsp),%eax
  401b9c:	69 c0 c9 3e 00 00    	imul   $0x3ec9,%eax,%eax
  401ba2:	89 44 24 04          	mov    %eax,0x4(%rsp)
  401ba6:	8b 44 24 24          	mov    0x24(%rsp),%eax
  401baa:	69 c0 3a 96 00 00    	imul   $0x963a,%eax,%eax
  401bb0:	89 44 24 24          	mov    %eax,0x24(%rsp)
  401bb4:	8b 44 24 18          	mov    0x18(%rsp),%eax
  401bb8:	69 c0 2d 0f 00 00    	imul   $0xf2d,%eax,%eax
  401bbe:	89 44 24 18          	mov    %eax,0x18(%rsp)
  401bc2:	8b 44 24 24          	mov    0x24(%rsp),%eax
  401bc6:	69 c0 41 80 00 00    	imul   $0x8041,%eax,%eax
  401bcc:	89 44 24 24          	mov    %eax,0x24(%rsp)
  401bd0:	8b 44 24 20          	mov    0x20(%rsp),%eax
  401bd4:	69 c0 66 a7 00 00    	imul   $0xa766,%eax,%eax
  401bda:	89 44 24 20          	mov    %eax,0x20(%rsp)
  401bde:	8b 44 24 14          	mov    0x14(%rsp),%eax
  401be2:	69 c0 74 6f 00 00    	imul   $0x6f74,%eax,%eax
  401be8:	89 44 24 14          	mov    %eax,0x14(%rsp)
  401bec:	8b 44 24 14          	mov    0x14(%rsp),%eax
  401bf0:	69 c0 5b 0c 00 00    	imul   $0xc5b,%eax,%eax
  401bf6:	89 44 24 14          	mov    %eax,0x14(%rsp)
  401bfa:	8b 44 24 1c          	mov    0x1c(%rsp),%eax
  401bfe:	69 c0 83 f7 00 00    	imul   $0xf783,%eax,%eax
  401c04:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
  401c08:	8b 44 24 10          	mov    0x10(%rsp),%eax
  401c0c:	69 c0 ca 9f 00 00    	imul   $0x9fca,%eax,%eax
  401c12:	89 44 24 10          	mov    %eax,0x10(%rsp)
  401c16:	8b 44 24 1c          	mov    0x1c(%rsp),%eax
  401c1a:	69 c0 85 e7 00 00    	imul   $0xe785,%eax,%eax
  401c20:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
  401c24:	8b 04 24             	mov    (%rsp),%eax
  401c27:	69 c0 5f 85 00 00    	imul   $0x855f,%eax,%eax
  401c2d:	89 04 24             	mov    %eax,(%rsp)
  401c30:	8b 04 24             	mov    (%rsp),%eax
  401c33:	69 c0 33 cc 00 00    	imul   $0xcc33,%eax,%eax
  401c39:	89 04 24             	mov    %eax,(%rsp)
  401c3c:	8b 44 24 10          	mov    0x10(%rsp),%eax
  401c40:	69 c0 52 f8 00 00    	imul   $0xf852,%eax,%eax
  401c46:	89 44 24 10          	mov    %eax,0x10(%rsp)
  401c4a:	8b 44 24 10          	mov    0x10(%rsp),%eax
  401c4e:	69 c0 03 c6 00 00    	imul   $0xc603,%eax,%eax
  401c54:	89 44 24 10          	mov    %eax,0x10(%rsp)
  401c58:	8b 44 24 24          	mov    0x24(%rsp),%eax
  401c5c:	69 c0 60 df 00 00    	imul   $0xdf60,%eax,%eax
  401c62:	89 44 24 24          	mov    %eax,0x24(%rsp)
  401c66:	8b 44 24 24          	mov    0x24(%rsp),%eax
  401c6a:	69 c0 ec 43 00 00    	imul   $0x43ec,%eax,%eax
  401c70:	89 44 24 24          	mov    %eax,0x24(%rsp)
  401c74:	8b 44 24 08          	mov    0x8(%rsp),%eax
  401c78:	69 c0 c9 2f 00 00    	imul   $0x2fc9,%eax,%eax
  401c7e:	89 44 24 08          	mov    %eax,0x8(%rsp)
  401c82:	8b 44 24 10          	mov    0x10(%rsp),%eax
  401c86:	69 c0 2e 06 00 00    	imul   $0x62e,%eax,%eax
  401c8c:	89 44 24 10          	mov    %eax,0x10(%rsp)
  401c90:	8b 44 24 20          	mov    0x20(%rsp),%eax
  401c94:	69 c0 a5 92 00 00    	imul   $0x92a5,%eax,%eax
  401c9a:	89 44 24 20          	mov    %eax,0x20(%rsp)
  401c9e:	8b 44 24 24          	mov    0x24(%rsp),%eax
  401ca2:	69 c0 19 b9 00 00    	imul   $0xb919,%eax,%eax
  401ca8:	89 44 24 24          	mov    %eax,0x24(%rsp)
  401cac:	8b 04 24             	mov    (%rsp),%eax
  401caf:	69 c0 82 a3 00 00    	imul   $0xa382,%eax,%eax
  401cb5:	89 04 24             	mov    %eax,(%rsp)
  401cb8:	8b 44 24 24          	mov    0x24(%rsp),%eax
  401cbc:	69 c0 8b b4 00 00    	imul   $0xb48b,%eax,%eax
  401cc2:	89 44 24 24          	mov    %eax,0x24(%rsp)
  401cc6:	8b 44 24 08          	mov    0x8(%rsp),%eax
  401cca:	69 c0 c5 ab 00 00    	imul   $0xabc5,%eax,%eax
  401cd0:	89 44 24 08          	mov    %eax,0x8(%rsp)
  401cd4:	8b 44 24 1c          	mov    0x1c(%rsp),%eax
  401cd8:	69 c0 5c 39 00 00    	imul   $0x395c,%eax,%eax
  401cde:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
  401ce2:	8b 44 24 10          	mov    0x10(%rsp),%eax
  401ce6:	69 c0 f8 b7 00 00    	imul   $0xb7f8,%eax,%eax
  401cec:	89 44 24 10          	mov    %eax,0x10(%rsp)
  401cf0:	8b 44 24 18          	mov    0x18(%rsp),%eax
  401cf4:	69 c0 bc f9 00 00    	imul   $0xf9bc,%eax,%eax
  401cfa:	89 44 24 18          	mov    %eax,0x18(%rsp)
  401cfe:	8b 44 24 14          	mov    0x14(%rsp),%eax
  401d02:	69 c0 cc d4 00 00    	imul   $0xd4cc,%eax,%eax
  401d08:	89 44 24 14          	mov    %eax,0x14(%rsp)
  401d0c:	8b 44 24 10          	mov    0x10(%rsp),%eax
  401d10:	69 c0 a6 bc 00 00    	imul   $0xbca6,%eax,%eax
  401d16:	89 44 24 10          	mov    %eax,0x10(%rsp)
  401d1a:	8b 44 24 20          	mov    0x20(%rsp),%eax
  401d1e:	69 c0 c4 93 00 00    	imul   $0x93c4,%eax,%eax
  401d24:	89 44 24 20          	mov    %eax,0x20(%rsp)
  401d28:	8b 44 24 08          	mov    0x8(%rsp),%eax
  401d2c:	69 c0 22 1f 00 00    	imul   $0x1f22,%eax,%eax
  401d32:	89 44 24 08          	mov    %eax,0x8(%rsp)
  401d36:	8b 44 24 0c          	mov    0xc(%rsp),%eax
  401d3a:	69 c0 4d 77 00 00    	imul   $0x774d,%eax,%eax
  401d40:	89 44 24 0c          	mov    %eax,0xc(%rsp)
  401d44:	8b 44 24 08          	mov    0x8(%rsp),%eax
  401d48:	69 c0 4d 91 00 00    	imul   $0x914d,%eax,%eax
  401d4e:	89 44 24 08          	mov    %eax,0x8(%rsp)
  401d52:	8b 44 24 10          	mov    0x10(%rsp),%eax
  401d56:	69 c0 35 3d 00 00    	imul   $0x3d35,%eax,%eax
  401d5c:	89 44 24 10          	mov    %eax,0x10(%rsp)
  401d60:	8b 44 24 20          	mov    0x20(%rsp),%eax
  401d64:	69 c0 0c e6 00 00    	imul   $0xe60c,%eax,%eax
  401d6a:	89 44 24 20          	mov    %eax,0x20(%rsp)
  401d6e:	8b 44 24 08          	mov    0x8(%rsp),%eax
  401d72:	69 c0 ec 1d 00 00    	imul   $0x1dec,%eax,%eax
  401d78:	89 44 24 08          	mov    %eax,0x8(%rsp)
  401d7c:	8b 44 24 08          	mov    0x8(%rsp),%eax
  401d80:	69 c0 e6 09 00 00    	imul   $0x9e6,%eax,%eax
  401d86:	89 44 24 08          	mov    %eax,0x8(%rsp)
  401d8a:	8b 44 24 1c          	mov    0x1c(%rsp),%eax
  401d8e:	69 c0 b4 c7 00 00    	imul   $0xc7b4,%eax,%eax
  401d94:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
  401d98:	8b 44 24 04          	mov    0x4(%rsp),%eax
  401d9c:	69 c0 4b 71 00 00    	imul   $0x714b,%eax,%eax
  401da2:	89 44 24 04          	mov    %eax,0x4(%rsp)
  401da6:	8b 44 24 24          	mov    0x24(%rsp),%eax
  401daa:	69 c0 7f 6a 00 00    	imul   $0x6a7f,%eax,%eax
  401db0:	89 44 24 24          	mov    %eax,0x24(%rsp)
  401db4:	8b 04 24             	mov    (%rsp),%eax
  401db7:	69 c0 08 bf 00 00    	imul   $0xbf08,%eax,%eax
  401dbd:	89 04 24             	mov    %eax,(%rsp)
  401dc0:	8b 44 24 10          	mov    0x10(%rsp),%eax
  401dc4:	69 c0 89 cb 00 00    	imul   $0xcb89,%eax,%eax
  401dca:	89 44 24 10          	mov    %eax,0x10(%rsp)
  401dce:	8b 44 24 20          	mov    0x20(%rsp),%eax
  401dd2:	69 c0 d0 5f 00 00    	imul   $0x5fd0,%eax,%eax
  401dd8:	89 44 24 20          	mov    %eax,0x20(%rsp)
  401ddc:	8b 44 24 10          	mov    0x10(%rsp),%eax
  401de0:	69 c0 b4 7e 00 00    	imul   $0x7eb4,%eax,%eax
  401de6:	89 44 24 10          	mov    %eax,0x10(%rsp)
  401dea:	8b 44 24 08          	mov    0x8(%rsp),%eax
  401dee:	69 c0 74 6d 00 00    	imul   $0x6d74,%eax,%eax
  401df4:	89 44 24 08          	mov    %eax,0x8(%rsp)
  401df8:	8b 44 24 1c          	mov    0x1c(%rsp),%eax
  401dfc:	69 c0 20 9f 00 00    	imul   $0x9f20,%eax,%eax
  401e02:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
  401e06:	8b 44 24 10          	mov    0x10(%rsp),%eax
  401e0a:	69 c0 9c 85 00 00    	imul   $0x859c,%eax,%eax
  401e10:	89 44 24 10          	mov    %eax,0x10(%rsp)
  401e14:	8b 44 24 1c          	mov    0x1c(%rsp),%eax
  401e18:	69 c0 a6 ef 00 00    	imul   $0xefa6,%eax,%eax
  401e1e:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
  401e22:	8b 44 24 24          	mov    0x24(%rsp),%eax
  401e26:	69 c0 84 bd 00 00    	imul   $0xbd84,%eax,%eax
  401e2c:	89 44 24 24          	mov    %eax,0x24(%rsp)
  401e30:	8b 44 24 14          	mov    0x14(%rsp),%eax
  401e34:	69 c0 65 ae 00 00    	imul   $0xae65,%eax,%eax
  401e3a:	89 44 24 14          	mov    %eax,0x14(%rsp)
  401e3e:	8b 44 24 1c          	mov    0x1c(%rsp),%eax
  401e42:	69 c0 b6 fc 00 00    	imul   $0xfcb6,%eax,%eax
  401e48:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
  401e4c:	8b 44 24 20          	mov    0x20(%rsp),%eax
  401e50:	69 c0 b7 42 00 00    	imul   $0x42b7,%eax,%eax
  401e56:	89 44 24 20          	mov    %eax,0x20(%rsp)
  401e5a:	8b 44 24 14          	mov    0x14(%rsp),%eax
  401e5e:	69 c0 bf 8d 00 00    	imul   $0x8dbf,%eax,%eax
  401e64:	89 44 24 14          	mov    %eax,0x14(%rsp)
  401e68:	8b 04 24             	mov    (%rsp),%eax
  401e6b:	69 c0 0d c5 00 00    	imul   $0xc50d,%eax,%eax
  401e71:	89 04 24             	mov    %eax,(%rsp)
  401e74:	8b 44 24 20          	mov    0x20(%rsp),%eax
  401e78:	69 c0 e4 7d 00 00    	imul   $0x7de4,%eax,%eax
  401e7e:	89 44 24 20          	mov    %eax,0x20(%rsp)
  401e82:	8b 44 24 18          	mov    0x18(%rsp),%eax
  401e86:	69 c0 b2 a9 00 00    	imul   $0xa9b2,%eax,%eax
  401e8c:	89 44 24 18          	mov    %eax,0x18(%rsp)
  401e90:	8b 44 24 14          	mov    0x14(%rsp),%eax
  401e94:	69 c0 04 52 00 00    	imul   $0x5204,%eax,%eax
  401e9a:	89 44 24 14          	mov    %eax,0x14(%rsp)
  401e9e:	8b 44 24 10          	mov    0x10(%rsp),%eax
  401ea2:	69 c0 b0 f5 00 00    	imul   $0xf5b0,%eax,%eax
  401ea8:	89 44 24 10          	mov    %eax,0x10(%rsp)
  401eac:	b8 00 00 00 00       	mov    $0x0,%eax
  401eb1:	ba 00 00 00 00       	mov    $0x0,%edx
  401eb6:	83 f8 09             	cmp    $0x9,%eax
  401eb9:	77 0c                	ja     401ec7 <scramble+0x55e>
  401ebb:	89 c1                	mov    %eax,%ecx
  401ebd:	8b 0c 8c             	mov    (%rsp,%rcx,4),%ecx
  401ec0:	01 ca                	add    %ecx,%edx
  401ec2:	83 c0 01             	add    $0x1,%eax
  401ec5:	eb ef                	jmp    401eb6 <scramble+0x54d>
  401ec7:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  401ecc:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
  401ed3:	00 00 
  401ed5:	75 07                	jne    401ede <scramble+0x575>
  401ed7:	89 d0                	mov    %edx,%eax
  401ed9:	48 83 c4 38          	add    $0x38,%rsp
  401edd:	c3                   	ret
  401ede:	e8 cd f3 ff ff       	call   4012b0 <__stack_chk_fail@plt>

0000000000401ee3 <getbuf>:
  401ee3:	f3 0f 1e fa          	endbr64
  401ee7:	48 83 ec 18          	sub    $0x18,%rsp
  401eeb:	48 89 e7             	mov    %rsp,%rdi
  401eee:	e8 b5 02 00 00       	call   4021a8 <Gets>
  401ef3:	b8 01 00 00 00       	mov    $0x1,%eax
  401ef8:	48 83 c4 18          	add    $0x18,%rsp
  401efc:	c3                   	ret

0000000000401efd <touch1>:
  401efd:	f3 0f 1e fa          	endbr64
  401f01:	50                   	push   %rax
  401f02:	58                   	pop    %rax
  401f03:	48 83 ec 08          	sub    $0x8,%rsp
  401f07:	c7 05 eb 55 00 00 01 	movl   $0x1,0x55eb(%rip)        # 4074fc <vlevel>
  401f0e:	00 00 00 
  401f11:	48 8d 3d 08 24 00 00 	lea    0x2408(%rip),%rdi        # 404320 <_IO_stdin_used+0x320>
  401f18:	e8 73 f3 ff ff       	call   401290 <puts@plt>
  401f1d:	bf 01 00 00 00       	mov    $0x1,%edi
  401f22:	e8 f4 04 00 00       	call   40241b <validate>
  401f27:	bf 00 00 00 00       	mov    $0x0,%edi
  401f2c:	e8 bf f4 ff ff       	call   4013f0 <exit@plt>

0000000000401f31 <touch2>:
  401f31:	f3 0f 1e fa          	endbr64
  401f35:	50                   	push   %rax
  401f36:	58                   	pop    %rax
  401f37:	48 83 ec 08          	sub    $0x8,%rsp
  401f3b:	89 fa                	mov    %edi,%edx
  401f3d:	c7 05 b5 55 00 00 02 	movl   $0x2,0x55b5(%rip)        # 4074fc <vlevel>
  401f44:	00 00 00 
  401f47:	39 3d b7 55 00 00    	cmp    %edi,0x55b7(%rip)        # 407504 <cookie>
  401f4d:	74 2a                	je     401f79 <touch2+0x48>
  401f4f:	48 8d 35 1a 24 00 00 	lea    0x241a(%rip),%rsi        # 404370 <_IO_stdin_used+0x370>
  401f56:	bf 01 00 00 00       	mov    $0x1,%edi
  401f5b:	b8 00 00 00 00       	mov    $0x0,%eax
  401f60:	e8 3b f4 ff ff       	call   4013a0 <__printf_chk@plt>
  401f65:	bf 02 00 00 00       	mov    $0x2,%edi
  401f6a:	e8 80 05 00 00       	call   4024ef <fail>
  401f6f:	bf 00 00 00 00       	mov    $0x0,%edi
  401f74:	e8 77 f4 ff ff       	call   4013f0 <exit@plt>
  401f79:	48 8d 35 c8 23 00 00 	lea    0x23c8(%rip),%rsi        # 404348 <_IO_stdin_used+0x348>
  401f80:	bf 01 00 00 00       	mov    $0x1,%edi
  401f85:	b8 00 00 00 00       	mov    $0x0,%eax
  401f8a:	e8 11 f4 ff ff       	call   4013a0 <__printf_chk@plt>
  401f8f:	bf 02 00 00 00       	mov    $0x2,%edi
  401f94:	e8 82 04 00 00       	call   40241b <validate>
  401f99:	eb d4                	jmp    401f6f <touch2+0x3e>

0000000000401f9b <hexmatch>:
  401f9b:	f3 0f 1e fa          	endbr64
  401f9f:	41 55                	push   %r13
  401fa1:	41 54                	push   %r12
  401fa3:	55                   	push   %rbp
  401fa4:	53                   	push   %rbx
  401fa5:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
  401fac:	89 fd                	mov    %edi,%ebp
  401fae:	48 89 f3             	mov    %rsi,%rbx
  401fb1:	41 bc 28 00 00 00    	mov    $0x28,%r12d
  401fb7:	64 49 8b 04 24       	mov    %fs:(%r12),%rax
  401fbc:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
  401fc1:	31 c0                	xor    %eax,%eax
  401fc3:	e8 a8 f3 ff ff       	call   401370 <random@plt>
  401fc8:	48 89 c1             	mov    %rax,%rcx
  401fcb:	48 ba 0b d7 a3 70 3d 	movabs $0xa3d70a3d70a3d70b,%rdx
  401fd2:	0a d7 a3 
  401fd5:	48 f7 ea             	imul   %rdx
  401fd8:	48 01 ca             	add    %rcx,%rdx
  401fdb:	48 c1 fa 06          	sar    $0x6,%rdx
  401fdf:	48 89 c8             	mov    %rcx,%rax
  401fe2:	48 c1 f8 3f          	sar    $0x3f,%rax
  401fe6:	48 29 c2             	sub    %rax,%rdx
  401fe9:	48 8d 04 92          	lea    (%rdx,%rdx,4),%rax
  401fed:	48 8d 04 80          	lea    (%rax,%rax,4),%rax
  401ff1:	48 c1 e0 02          	shl    $0x2,%rax
  401ff5:	48 29 c1             	sub    %rax,%rcx
  401ff8:	4c 8d 2c 0c          	lea    (%rsp,%rcx,1),%r13
  401ffc:	41 89 e8             	mov    %ebp,%r8d
  401fff:	48 8d 0d 37 23 00 00 	lea    0x2337(%rip),%rcx        # 40433d <_IO_stdin_used+0x33d>
  402006:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  40200d:	be 01 00 00 00       	mov    $0x1,%esi
  402012:	4c 89 ef             	mov    %r13,%rdi
  402015:	b8 00 00 00 00       	mov    $0x0,%eax
  40201a:	e8 11 f4 ff ff       	call   401430 <__sprintf_chk@plt>
  40201f:	ba 09 00 00 00       	mov    $0x9,%edx
  402024:	4c 89 ee             	mov    %r13,%rsi
  402027:	48 89 df             	mov    %rbx,%rdi
  40202a:	e8 41 f2 ff ff       	call   401270 <strncmp@plt>
  40202f:	85 c0                	test   %eax,%eax
  402031:	0f 94 c0             	sete   %al
  402034:	48 8b 5c 24 78       	mov    0x78(%rsp),%rbx
  402039:	64 49 33 1c 24       	xor    %fs:(%r12),%rbx
  40203e:	75 11                	jne    402051 <hexmatch+0xb6>
  402040:	0f b6 c0             	movzbl %al,%eax
  402043:	48 81 c4 88 00 00 00 	add    $0x88,%rsp
  40204a:	5b                   	pop    %rbx
  40204b:	5d                   	pop    %rbp
  40204c:	41 5c                	pop    %r12
  40204e:	41 5d                	pop    %r13
  402050:	c3                   	ret
  402051:	e8 5a f2 ff ff       	call   4012b0 <__stack_chk_fail@plt>

0000000000402056 <touch3>:
  402056:	f3 0f 1e fa          	endbr64
  40205a:	53                   	push   %rbx
  40205b:	48 89 fb             	mov    %rdi,%rbx
  40205e:	c7 05 94 54 00 00 03 	movl   $0x3,0x5494(%rip)        # 4074fc <vlevel>
  402065:	00 00 00 
  402068:	48 89 fe             	mov    %rdi,%rsi
  40206b:	8b 3d 93 54 00 00    	mov    0x5493(%rip),%edi        # 407504 <cookie>
  402071:	e8 25 ff ff ff       	call   401f9b <hexmatch>
  402076:	85 c0                	test   %eax,%eax
  402078:	74 2d                	je     4020a7 <touch3+0x51>
  40207a:	48 89 da             	mov    %rbx,%rdx
  40207d:	48 8d 35 14 23 00 00 	lea    0x2314(%rip),%rsi        # 404398 <_IO_stdin_used+0x398>
  402084:	bf 01 00 00 00       	mov    $0x1,%edi
  402089:	b8 00 00 00 00       	mov    $0x0,%eax
  40208e:	e8 0d f3 ff ff       	call   4013a0 <__printf_chk@plt>
  402093:	bf 03 00 00 00       	mov    $0x3,%edi
  402098:	e8 7e 03 00 00       	call   40241b <validate>
  40209d:	bf 00 00 00 00       	mov    $0x0,%edi
  4020a2:	e8 49 f3 ff ff       	call   4013f0 <exit@plt>
  4020a7:	48 89 da             	mov    %rbx,%rdx
  4020aa:	48 8d 35 0f 23 00 00 	lea    0x230f(%rip),%rsi        # 4043c0 <_IO_stdin_used+0x3c0>
  4020b1:	bf 01 00 00 00       	mov    $0x1,%edi
  4020b6:	b8 00 00 00 00       	mov    $0x0,%eax
  4020bb:	e8 e0 f2 ff ff       	call   4013a0 <__printf_chk@plt>
  4020c0:	bf 03 00 00 00       	mov    $0x3,%edi
  4020c5:	e8 25 04 00 00       	call   4024ef <fail>
  4020ca:	eb d1                	jmp    40209d <touch3+0x47>

00000000004020cc <test>:
  4020cc:	f3 0f 1e fa          	endbr64
  4020d0:	48 83 ec 08          	sub    $0x8,%rsp
  4020d4:	b8 00 00 00 00       	mov    $0x0,%eax
  4020d9:	e8 05 fe ff ff       	call   401ee3 <getbuf>
  4020de:	89 c2                	mov    %eax,%edx
  4020e0:	48 8d 35 01 23 00 00 	lea    0x2301(%rip),%rsi        # 4043e8 <_IO_stdin_used+0x3e8>
  4020e7:	bf 01 00 00 00       	mov    $0x1,%edi
  4020ec:	b8 00 00 00 00       	mov    $0x0,%eax
  4020f1:	e8 aa f2 ff ff       	call   4013a0 <__printf_chk@plt>
  4020f6:	48 83 c4 08          	add    $0x8,%rsp
  4020fa:	c3                   	ret

00000000004020fb <save_char>:
  4020fb:	8b 05 23 60 00 00    	mov    0x6023(%rip),%eax        # 408124 <gets_cnt>
  402101:	3d ff 03 00 00       	cmp    $0x3ff,%eax
  402106:	7f 4a                	jg     402152 <save_char+0x57>
  402108:	89 f9                	mov    %edi,%ecx
  40210a:	c0 e9 04             	shr    $0x4,%cl
  40210d:	8d 14 40             	lea    (%rax,%rax,2),%edx
  402110:	4c 8d 05 f9 25 00 00 	lea    0x25f9(%rip),%r8        # 404710 <trans_char>
  402117:	83 e1 0f             	and    $0xf,%ecx
  40211a:	45 0f b6 0c 08       	movzbl (%r8,%rcx,1),%r9d
  40211f:	48 8d 0d fa 53 00 00 	lea    0x53fa(%rip),%rcx        # 407520 <gets_buf>
  402126:	48 63 f2             	movslq %edx,%rsi
  402129:	44 88 0c 31          	mov    %r9b,(%rcx,%rsi,1)
  40212d:	8d 72 01             	lea    0x1(%rdx),%esi
  402130:	83 e7 0f             	and    $0xf,%edi
  402133:	41 0f b6 3c 38       	movzbl (%r8,%rdi,1),%edi
  402138:	48 63 f6             	movslq %esi,%rsi
  40213b:	40 88 3c 31          	mov    %dil,(%rcx,%rsi,1)
  40213f:	83 c2 02             	add    $0x2,%edx
  402142:	48 63 d2             	movslq %edx,%rdx
  402145:	c6 04 11 20          	movb   $0x20,(%rcx,%rdx,1)
  402149:	83 c0 01             	add    $0x1,%eax
  40214c:	89 05 d2 5f 00 00    	mov    %eax,0x5fd2(%rip)        # 408124 <gets_cnt>
  402152:	c3                   	ret

0000000000402153 <save_term>:
  402153:	8b 05 cb 5f 00 00    	mov    0x5fcb(%rip),%eax        # 408124 <gets_cnt>
  402159:	8d 04 40             	lea    (%rax,%rax,2),%eax
  40215c:	48 98                	cltq
  40215e:	48 8d 15 bb 53 00 00 	lea    0x53bb(%rip),%rdx        # 407520 <gets_buf>
  402165:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
  402169:	c3                   	ret

000000000040216a <check_fail>:
  40216a:	f3 0f 1e fa          	endbr64
  40216e:	50                   	push   %rax
  40216f:	58                   	pop    %rax
  402170:	48 83 ec 08          	sub    $0x8,%rsp
  402174:	0f be 15 ad 5f 00 00 	movsbl 0x5fad(%rip),%edx        # 408128 <target_prefix>
  40217b:	4c 8d 05 9e 53 00 00 	lea    0x539e(%rip),%r8        # 407520 <gets_buf>
  402182:	8b 0d 70 53 00 00    	mov    0x5370(%rip),%ecx        # 4074f8 <check_level>
  402188:	48 8d 35 7c 22 00 00 	lea    0x227c(%rip),%rsi        # 40440b <_IO_stdin_used+0x40b>
  40218f:	bf 01 00 00 00       	mov    $0x1,%edi
  402194:	b8 00 00 00 00       	mov    $0x0,%eax
  402199:	e8 02 f2 ff ff       	call   4013a0 <__printf_chk@plt>
  40219e:	bf 01 00 00 00       	mov    $0x1,%edi
  4021a3:	e8 48 f2 ff ff       	call   4013f0 <exit@plt>

00000000004021a8 <Gets>:
  4021a8:	f3 0f 1e fa          	endbr64
  4021ac:	41 54                	push   %r12
  4021ae:	55                   	push   %rbp
  4021af:	53                   	push   %rbx
  4021b0:	49 89 fc             	mov    %rdi,%r12
  4021b3:	c7 05 67 5f 00 00 00 	movl   $0x0,0x5f67(%rip)        # 408124 <gets_cnt>
  4021ba:	00 00 00 
  4021bd:	48 89 fb             	mov    %rdi,%rbx
  4021c0:	48 8b 3d 29 53 00 00 	mov    0x5329(%rip),%rdi        # 4074f0 <infile>
  4021c7:	e8 54 f2 ff ff       	call   401420 <getc@plt>
  4021cc:	83 f8 ff             	cmp    $0xffffffff,%eax
  4021cf:	74 18                	je     4021e9 <Gets+0x41>
  4021d1:	83 f8 0a             	cmp    $0xa,%eax
  4021d4:	74 13                	je     4021e9 <Gets+0x41>
  4021d6:	48 8d 6b 01          	lea    0x1(%rbx),%rbp
  4021da:	88 03                	mov    %al,(%rbx)
  4021dc:	0f b6 f8             	movzbl %al,%edi
  4021df:	e8 17 ff ff ff       	call   4020fb <save_char>
  4021e4:	48 89 eb             	mov    %rbp,%rbx
  4021e7:	eb d7                	jmp    4021c0 <Gets+0x18>
  4021e9:	c6 03 00             	movb   $0x0,(%rbx)
  4021ec:	b8 00 00 00 00       	mov    $0x0,%eax
  4021f1:	e8 5d ff ff ff       	call   402153 <save_term>
  4021f6:	4c 89 e0             	mov    %r12,%rax
  4021f9:	5b                   	pop    %rbx
  4021fa:	5d                   	pop    %rbp
  4021fb:	41 5c                	pop    %r12
  4021fd:	c3                   	ret

00000000004021fe <notify_server>:
  4021fe:	f3 0f 1e fa          	endbr64
  402202:	55                   	push   %rbp
  402203:	53                   	push   %rbx
  402204:	4c 8d 9c 24 00 c0 ff 	lea    -0x4000(%rsp),%r11
  40220b:	ff 
  40220c:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
  402213:	48 83 0c 24 00       	orq    $0x0,(%rsp)
  402218:	4c 39 dc             	cmp    %r11,%rsp
  40221b:	75 ef                	jne    40220c <notify_server+0xe>
  40221d:	48 83 ec 18          	sub    $0x18,%rsp
  402221:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
  402228:	00 00 
  40222a:	48 89 84 24 08 40 00 	mov    %rax,0x4008(%rsp)
  402231:	00 
  402232:	31 c0                	xor    %eax,%eax
  402234:	83 3d cd 52 00 00 00 	cmpl   $0x0,0x52cd(%rip)        # 407508 <is_checker>
  40223b:	0f 85 26 01 00 00    	jne    402367 <notify_server+0x169>
  402241:	89 fb                	mov    %edi,%ebx
  402243:	81 3d d7 5e 00 00 9c 	cmpl   $0x1f9c,0x5ed7(%rip)        # 408124 <gets_cnt>
  40224a:	1f 00 00 
  40224d:	7f 18                	jg     402267 <notify_server+0x69>
  40224f:	0f be 05 d2 5e 00 00 	movsbl 0x5ed2(%rip),%eax        # 408128 <target_prefix>
  402256:	83 3d 2b 52 00 00 00 	cmpl   $0x0,0x522b(%rip)        # 407488 <notify>
  40225d:	74 23                	je     402282 <notify_server+0x84>
  40225f:	8b 15 9b 52 00 00    	mov    0x529b(%rip),%edx        # 407500 <authkey>
  402265:	eb 20                	jmp    402287 <notify_server+0x89>
  402267:	48 8d 35 d2 22 00 00 	lea    0x22d2(%rip),%rsi        # 404540 <_IO_stdin_used+0x540>
  40226e:	bf 01 00 00 00       	mov    $0x1,%edi
  402273:	e8 28 f1 ff ff       	call   4013a0 <__printf_chk@plt>
  402278:	bf 01 00 00 00       	mov    $0x1,%edi
  40227d:	e8 6e f1 ff ff       	call   4013f0 <exit@plt>
  402282:	ba ff ff ff ff       	mov    $0xffffffff,%edx
  402287:	85 db                	test   %ebx,%ebx
  402289:	0f 84 98 00 00 00    	je     402327 <notify_server+0x129>
  40228f:	48 8d 2d 90 21 00 00 	lea    0x2190(%rip),%rbp        # 404426 <_IO_stdin_used+0x426>
  402296:	48 89 e7             	mov    %rsp,%rdi
  402299:	48 8d 0d 80 52 00 00 	lea    0x5280(%rip),%rcx        # 407520 <gets_buf>
  4022a0:	51                   	push   %rcx
  4022a1:	56                   	push   %rsi
  4022a2:	50                   	push   %rax
  4022a3:	52                   	push   %rdx
  4022a4:	49 89 e9             	mov    %rbp,%r9
  4022a7:	44 8b 05 82 4e 00 00 	mov    0x4e82(%rip),%r8d        # 407130 <target_id>
  4022ae:	48 8d 0d 76 21 00 00 	lea    0x2176(%rip),%rcx        # 40442b <_IO_stdin_used+0x42b>
  4022b5:	ba 00 20 00 00       	mov    $0x2000,%edx
  4022ba:	be 01 00 00 00       	mov    $0x1,%esi
  4022bf:	b8 00 00 00 00       	mov    $0x0,%eax
  4022c4:	e8 67 f1 ff ff       	call   401430 <__sprintf_chk@plt>
  4022c9:	48 83 c4 20          	add    $0x20,%rsp
  4022cd:	83 3d b4 51 00 00 00 	cmpl   $0x0,0x51b4(%rip)        # 407488 <notify>
  4022d4:	0f 84 ae 00 00 00    	je     402388 <notify_server+0x18a>
  4022da:	85 db                	test   %ebx,%ebx
  4022dc:	74 7d                	je     40235b <notify_server+0x15d>
  4022de:	48 89 e1             	mov    %rsp,%rcx
  4022e1:	4c 8d 8c 24 00 20 00 	lea    0x2000(%rsp),%r9
  4022e8:	00 
  4022e9:	41 b8 00 00 00 00    	mov    $0x0,%r8d
  4022ef:	48 8b 15 52 4e 00 00 	mov    0x4e52(%rip),%rdx        # 407148 <lab>
  4022f6:	48 8b 35 53 4e 00 00 	mov    0x4e53(%rip),%rsi        # 407150 <course>
  4022fd:	48 8b 3d 3c 4e 00 00 	mov    0x4e3c(%rip),%rdi        # 407140 <user_id>
  402304:	e8 d9 11 00 00       	call   4034e2 <driver_post>
  402309:	85 c0                	test   %eax,%eax
  40230b:	78 26                	js     402333 <notify_server+0x135>
  40230d:	48 8d 3d 5c 22 00 00 	lea    0x225c(%rip),%rdi        # 404570 <_IO_stdin_used+0x570>
  402314:	e8 77 ef ff ff       	call   401290 <puts@plt>
  402319:	48 8d 3d 33 21 00 00 	lea    0x2133(%rip),%rdi        # 404453 <_IO_stdin_used+0x453>
  402320:	e8 6b ef ff ff       	call   401290 <puts@plt>
  402325:	eb 40                	jmp    402367 <notify_server+0x169>
  402327:	48 8d 2d f3 20 00 00 	lea    0x20f3(%rip),%rbp        # 404421 <_IO_stdin_used+0x421>
  40232e:	e9 63 ff ff ff       	jmp    402296 <notify_server+0x98>
  402333:	48 8d 94 24 00 20 00 	lea    0x2000(%rsp),%rdx
  40233a:	00 
  40233b:	48 8d 35 05 21 00 00 	lea    0x2105(%rip),%rsi        # 404447 <_IO_stdin_used+0x447>
  402342:	bf 01 00 00 00       	mov    $0x1,%edi
  402347:	b8 00 00 00 00       	mov    $0x0,%eax
  40234c:	e8 4f f0 ff ff       	call   4013a0 <__printf_chk@plt>
  402351:	bf 01 00 00 00       	mov    $0x1,%edi
  402356:	e8 95 f0 ff ff       	call   4013f0 <exit@plt>
  40235b:	48 8d 3d fb 20 00 00 	lea    0x20fb(%rip),%rdi        # 40445d <_IO_stdin_used+0x45d>
  402362:	e8 29 ef ff ff       	call   401290 <puts@plt>
  402367:	48 8b 84 24 08 40 00 	mov    0x4008(%rsp),%rax
  40236e:	00 
  40236f:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
  402376:	00 00 
  402378:	0f 85 98 00 00 00    	jne    402416 <notify_server+0x218>
  40237e:	48 81 c4 18 40 00 00 	add    $0x4018,%rsp
  402385:	5b                   	pop    %rbx
  402386:	5d                   	pop    %rbp
  402387:	c3                   	ret
  402388:	48 89 ea             	mov    %rbp,%rdx
  40238b:	48 8d 35 16 22 00 00 	lea    0x2216(%rip),%rsi        # 4045a8 <_IO_stdin_used+0x5a8>
  402392:	bf 01 00 00 00       	mov    $0x1,%edi
  402397:	b8 00 00 00 00       	mov    $0x0,%eax
  40239c:	e8 ff ef ff ff       	call   4013a0 <__printf_chk@plt>
  4023a1:	48 8b 15 98 4d 00 00 	mov    0x4d98(%rip),%rdx        # 407140 <user_id>
  4023a8:	48 8d 35 b5 20 00 00 	lea    0x20b5(%rip),%rsi        # 404464 <_IO_stdin_used+0x464>
  4023af:	bf 01 00 00 00       	mov    $0x1,%edi
  4023b4:	b8 00 00 00 00       	mov    $0x0,%eax
  4023b9:	e8 e2 ef ff ff       	call   4013a0 <__printf_chk@plt>
  4023be:	48 8b 15 8b 4d 00 00 	mov    0x4d8b(%rip),%rdx        # 407150 <course>
  4023c5:	48 8d 35 a5 20 00 00 	lea    0x20a5(%rip),%rsi        # 404471 <_IO_stdin_used+0x471>
  4023cc:	bf 01 00 00 00       	mov    $0x1,%edi
  4023d1:	b8 00 00 00 00       	mov    $0x0,%eax
  4023d6:	e8 c5 ef ff ff       	call   4013a0 <__printf_chk@plt>
  4023db:	48 8b 15 66 4d 00 00 	mov    0x4d66(%rip),%rdx        # 407148 <lab>
  4023e2:	48 8d 35 94 20 00 00 	lea    0x2094(%rip),%rsi        # 40447d <_IO_stdin_used+0x47d>
  4023e9:	bf 01 00 00 00       	mov    $0x1,%edi
  4023ee:	b8 00 00 00 00       	mov    $0x0,%eax
  4023f3:	e8 a8 ef ff ff       	call   4013a0 <__printf_chk@plt>
  4023f8:	48 89 e2             	mov    %rsp,%rdx
  4023fb:	48 8d 35 84 20 00 00 	lea    0x2084(%rip),%rsi        # 404486 <_IO_stdin_used+0x486>
  402402:	bf 01 00 00 00       	mov    $0x1,%edi
  402407:	b8 00 00 00 00       	mov    $0x0,%eax
  40240c:	e8 8f ef ff ff       	call   4013a0 <__printf_chk@plt>
  402411:	e9 51 ff ff ff       	jmp    402367 <notify_server+0x169>
  402416:	e8 95 ee ff ff       	call   4012b0 <__stack_chk_fail@plt>

000000000040241b <validate>:
  40241b:	f3 0f 1e fa          	endbr64
  40241f:	53                   	push   %rbx
  402420:	89 fb                	mov    %edi,%ebx
  402422:	83 3d df 50 00 00 00 	cmpl   $0x0,0x50df(%rip)        # 407508 <is_checker>
  402429:	74 72                	je     40249d <validate+0x82>
  40242b:	39 3d cb 50 00 00    	cmp    %edi,0x50cb(%rip)        # 4074fc <vlevel>
  402431:	75 32                	jne    402465 <validate+0x4a>
  402433:	8b 15 bf 50 00 00    	mov    0x50bf(%rip),%edx        # 4074f8 <check_level>
  402439:	39 fa                	cmp    %edi,%edx
  40243b:	75 3e                	jne    40247b <validate+0x60>
  40243d:	0f be 15 e4 5c 00 00 	movsbl 0x5ce4(%rip),%edx        # 408128 <target_prefix>
  402444:	4c 8d 05 d5 50 00 00 	lea    0x50d5(%rip),%r8        # 407520 <gets_buf>
  40244b:	89 f9                	mov    %edi,%ecx
  40244d:	48 8d 35 5c 20 00 00 	lea    0x205c(%rip),%rsi        # 4044b0 <_IO_stdin_used+0x4b0>
  402454:	bf 01 00 00 00       	mov    $0x1,%edi
  402459:	b8 00 00 00 00       	mov    $0x0,%eax
  40245e:	e8 3d ef ff ff       	call   4013a0 <__printf_chk@plt>
  402463:	5b                   	pop    %rbx
  402464:	c3                   	ret
  402465:	48 8d 3d 26 20 00 00 	lea    0x2026(%rip),%rdi        # 404492 <_IO_stdin_used+0x492>
  40246c:	e8 1f ee ff ff       	call   401290 <puts@plt>
  402471:	b8 00 00 00 00       	mov    $0x0,%eax
  402476:	e8 ef fc ff ff       	call   40216a <check_fail>
  40247b:	89 f9                	mov    %edi,%ecx
  40247d:	48 8d 35 4c 21 00 00 	lea    0x214c(%rip),%rsi        # 4045d0 <_IO_stdin_used+0x5d0>
  402484:	bf 01 00 00 00       	mov    $0x1,%edi
  402489:	b8 00 00 00 00       	mov    $0x0,%eax
  40248e:	e8 0d ef ff ff       	call   4013a0 <__printf_chk@plt>
  402493:	b8 00 00 00 00       	mov    $0x0,%eax
  402498:	e8 cd fc ff ff       	call   40216a <check_fail>
  40249d:	39 3d 59 50 00 00    	cmp    %edi,0x5059(%rip)        # 4074fc <vlevel>
  4024a3:	74 1a                	je     4024bf <validate+0xa4>
  4024a5:	48 8d 3d e6 1f 00 00 	lea    0x1fe6(%rip),%rdi        # 404492 <_IO_stdin_used+0x492>
  4024ac:	e8 df ed ff ff       	call   401290 <puts@plt>
  4024b1:	89 de                	mov    %ebx,%esi
  4024b3:	bf 00 00 00 00       	mov    $0x0,%edi
  4024b8:	e8 41 fd ff ff       	call   4021fe <notify_server>
  4024bd:	eb a4                	jmp    402463 <validate+0x48>
  4024bf:	0f be 0d 62 5c 00 00 	movsbl 0x5c62(%rip),%ecx        # 408128 <target_prefix>
  4024c6:	89 fa                	mov    %edi,%edx
  4024c8:	48 8d 35 29 21 00 00 	lea    0x2129(%rip),%rsi        # 4045f8 <_IO_stdin_used+0x5f8>
  4024cf:	bf 01 00 00 00       	mov    $0x1,%edi
  4024d4:	b8 00 00 00 00       	mov    $0x0,%eax
  4024d9:	e8 c2 ee ff ff       	call   4013a0 <__printf_chk@plt>
  4024de:	89 de                	mov    %ebx,%esi
  4024e0:	bf 01 00 00 00       	mov    $0x1,%edi
  4024e5:	e8 14 fd ff ff       	call   4021fe <notify_server>
  4024ea:	e9 74 ff ff ff       	jmp    402463 <validate+0x48>

00000000004024ef <fail>:
  4024ef:	f3 0f 1e fa          	endbr64
  4024f3:	48 83 ec 08          	sub    $0x8,%rsp
  4024f7:	83 3d 0a 50 00 00 00 	cmpl   $0x0,0x500a(%rip)        # 407508 <is_checker>
  4024fe:	75 11                	jne    402511 <fail+0x22>
  402500:	89 fe                	mov    %edi,%esi
  402502:	bf 00 00 00 00       	mov    $0x0,%edi
  402507:	e8 f2 fc ff ff       	call   4021fe <notify_server>
  40250c:	48 83 c4 08          	add    $0x8,%rsp
  402510:	c3                   	ret
  402511:	b8 00 00 00 00       	mov    $0x0,%eax
  402516:	e8 4f fc ff ff       	call   40216a <check_fail>

000000000040251b <bushandler>:
  40251b:	f3 0f 1e fa          	endbr64
  40251f:	50                   	push   %rax
  402520:	58                   	pop    %rax
  402521:	48 83 ec 08          	sub    $0x8,%rsp
  402525:	83 3d dc 4f 00 00 00 	cmpl   $0x0,0x4fdc(%rip)        # 407508 <is_checker>
  40252c:	74 16                	je     402544 <bushandler+0x29>
  40252e:	48 8d 3d 90 1f 00 00 	lea    0x1f90(%rip),%rdi        # 4044c5 <_IO_stdin_used+0x4c5>
  402535:	e8 56 ed ff ff       	call   401290 <puts@plt>
  40253a:	b8 00 00 00 00       	mov    $0x0,%eax
  40253f:	e8 26 fc ff ff       	call   40216a <check_fail>
  402544:	48 8d 3d e5 20 00 00 	lea    0x20e5(%rip),%rdi        # 404630 <_IO_stdin_used+0x630>
  40254b:	e8 40 ed ff ff       	call   401290 <puts@plt>
  402550:	48 8d 3d 78 1f 00 00 	lea    0x1f78(%rip),%rdi        # 4044cf <_IO_stdin_used+0x4cf>
  402557:	e8 34 ed ff ff       	call   401290 <puts@plt>
  40255c:	be 00 00 00 00       	mov    $0x0,%esi
  402561:	bf 00 00 00 00       	mov    $0x0,%edi
  402566:	e8 93 fc ff ff       	call   4021fe <notify_server>
  40256b:	bf 01 00 00 00       	mov    $0x1,%edi
  402570:	e8 7b ee ff ff       	call   4013f0 <exit@plt>

0000000000402575 <seghandler>:
  402575:	f3 0f 1e fa          	endbr64
  402579:	50                   	push   %rax
  40257a:	58                   	pop    %rax
  40257b:	48 83 ec 08          	sub    $0x8,%rsp
  40257f:	83 3d 82 4f 00 00 00 	cmpl   $0x0,0x4f82(%rip)        # 407508 <is_checker>
  402586:	74 16                	je     40259e <seghandler+0x29>
  402588:	48 8d 3d 56 1f 00 00 	lea    0x1f56(%rip),%rdi        # 4044e5 <_IO_stdin_used+0x4e5>
  40258f:	e8 fc ec ff ff       	call   401290 <puts@plt>
  402594:	b8 00 00 00 00       	mov    $0x0,%eax
  402599:	e8 cc fb ff ff       	call   40216a <check_fail>
  40259e:	48 8d 3d ab 20 00 00 	lea    0x20ab(%rip),%rdi        # 404650 <_IO_stdin_used+0x650>
  4025a5:	e8 e6 ec ff ff       	call   401290 <puts@plt>
  4025aa:	48 8d 3d 1e 1f 00 00 	lea    0x1f1e(%rip),%rdi        # 4044cf <_IO_stdin_used+0x4cf>
  4025b1:	e8 da ec ff ff       	call   401290 <puts@plt>
  4025b6:	be 00 00 00 00       	mov    $0x0,%esi
  4025bb:	bf 00 00 00 00       	mov    $0x0,%edi
  4025c0:	e8 39 fc ff ff       	call   4021fe <notify_server>
  4025c5:	bf 01 00 00 00       	mov    $0x1,%edi
  4025ca:	e8 21 ee ff ff       	call   4013f0 <exit@plt>

00000000004025cf <illegalhandler>:
  4025cf:	f3 0f 1e fa          	endbr64
  4025d3:	50                   	push   %rax
  4025d4:	58                   	pop    %rax
  4025d5:	48 83 ec 08          	sub    $0x8,%rsp
  4025d9:	83 3d 28 4f 00 00 00 	cmpl   $0x0,0x4f28(%rip)        # 407508 <is_checker>
  4025e0:	74 16                	je     4025f8 <illegalhandler+0x29>
  4025e2:	48 8d 3d 0f 1f 00 00 	lea    0x1f0f(%rip),%rdi        # 4044f8 <_IO_stdin_used+0x4f8>
  4025e9:	e8 a2 ec ff ff       	call   401290 <puts@plt>
  4025ee:	b8 00 00 00 00       	mov    $0x0,%eax
  4025f3:	e8 72 fb ff ff       	call   40216a <check_fail>
  4025f8:	48 8d 3d 79 20 00 00 	lea    0x2079(%rip),%rdi        # 404678 <_IO_stdin_used+0x678>
  4025ff:	e8 8c ec ff ff       	call   401290 <puts@plt>
  402604:	48 8d 3d c4 1e 00 00 	lea    0x1ec4(%rip),%rdi        # 4044cf <_IO_stdin_used+0x4cf>
  40260b:	e8 80 ec ff ff       	call   401290 <puts@plt>
  402610:	be 00 00 00 00       	mov    $0x0,%esi
  402615:	bf 00 00 00 00       	mov    $0x0,%edi
  40261a:	e8 df fb ff ff       	call   4021fe <notify_server>
  40261f:	bf 01 00 00 00       	mov    $0x1,%edi
  402624:	e8 c7 ed ff ff       	call   4013f0 <exit@plt>

0000000000402629 <sigalrmhandler>:
  402629:	f3 0f 1e fa          	endbr64
  40262d:	50                   	push   %rax
  40262e:	58                   	pop    %rax
  40262f:	48 83 ec 08          	sub    $0x8,%rsp
  402633:	83 3d ce 4e 00 00 00 	cmpl   $0x0,0x4ece(%rip)        # 407508 <is_checker>
  40263a:	74 16                	je     402652 <sigalrmhandler+0x29>
  40263c:	48 8d 3d c9 1e 00 00 	lea    0x1ec9(%rip),%rdi        # 40450c <_IO_stdin_used+0x50c>
  402643:	e8 48 ec ff ff       	call   401290 <puts@plt>
  402648:	b8 00 00 00 00       	mov    $0x0,%eax
  40264d:	e8 18 fb ff ff       	call   40216a <check_fail>
  402652:	ba 05 00 00 00       	mov    $0x5,%edx
  402657:	48 8d 35 4a 20 00 00 	lea    0x204a(%rip),%rsi        # 4046a8 <_IO_stdin_used+0x6a8>
  40265e:	bf 01 00 00 00       	mov    $0x1,%edi
  402663:	b8 00 00 00 00       	mov    $0x0,%eax
  402668:	e8 33 ed ff ff       	call   4013a0 <__printf_chk@plt>
  40266d:	be 00 00 00 00       	mov    $0x0,%esi
  402672:	bf 00 00 00 00       	mov    $0x0,%edi
  402677:	e8 82 fb ff ff       	call   4021fe <notify_server>
  40267c:	bf 01 00 00 00       	mov    $0x1,%edi
  402681:	e8 6a ed ff ff       	call   4013f0 <exit@plt>

0000000000402686 <launch>:
  402686:	f3 0f 1e fa          	endbr64
  40268a:	55                   	push   %rbp
  40268b:	48 89 e5             	mov    %rsp,%rbp
  40268e:	48 83 ec 10          	sub    $0x10,%rsp
  402692:	48 89 fa             	mov    %rdi,%rdx
  402695:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
  40269c:	00 00 
  40269e:	48 89 45 f8          	mov    %rax,-0x8(%rbp)
  4026a2:	31 c0                	xor    %eax,%eax
  4026a4:	48 8d 47 17          	lea    0x17(%rdi),%rax
  4026a8:	48 89 c1             	mov    %rax,%rcx
  4026ab:	48 83 e1 f0          	and    $0xfffffffffffffff0,%rcx
  4026af:	48 25 00 f0 ff ff    	and    $0xfffffffffffff000,%rax
  4026b5:	48 89 e6             	mov    %rsp,%rsi
  4026b8:	48 29 c6             	sub    %rax,%rsi
  4026bb:	48 89 f0             	mov    %rsi,%rax
  4026be:	48 39 c4             	cmp    %rax,%rsp
  4026c1:	74 12                	je     4026d5 <launch+0x4f>
  4026c3:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
  4026ca:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
  4026d1:	00 00 
  4026d3:	eb e9                	jmp    4026be <launch+0x38>
  4026d5:	48 89 c8             	mov    %rcx,%rax
  4026d8:	25 ff 0f 00 00       	and    $0xfff,%eax
  4026dd:	48 29 c4             	sub    %rax,%rsp
  4026e0:	48 85 c0             	test   %rax,%rax
  4026e3:	74 06                	je     4026eb <launch+0x65>
  4026e5:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
  4026eb:	48 8d 7c 24 0f       	lea    0xf(%rsp),%rdi
  4026f0:	48 83 e7 f0          	and    $0xfffffffffffffff0,%rdi
  4026f4:	be f4 00 00 00       	mov    $0xf4,%esi
  4026f9:	e8 d2 eb ff ff       	call   4012d0 <memset@plt>
  4026fe:	48 8b 05 9b 4d 00 00 	mov    0x4d9b(%rip),%rax        # 4074a0 <stdin@GLIBC_2.2.5>
  402705:	48 39 05 e4 4d 00 00 	cmp    %rax,0x4de4(%rip)        # 4074f0 <infile>
  40270c:	74 3a                	je     402748 <launch+0xc2>
  40270e:	c7 05 e4 4d 00 00 00 	movl   $0x0,0x4de4(%rip)        # 4074fc <vlevel>
  402715:	00 00 00 
  402718:	b8 00 00 00 00       	mov    $0x0,%eax
  40271d:	e8 aa f9 ff ff       	call   4020cc <test>
  402722:	83 3d df 4d 00 00 00 	cmpl   $0x0,0x4ddf(%rip)        # 407508 <is_checker>
  402729:	75 35                	jne    402760 <launch+0xda>
  40272b:	48 8d 3d fa 1d 00 00 	lea    0x1dfa(%rip),%rdi        # 40452c <_IO_stdin_used+0x52c>
  402732:	e8 59 eb ff ff       	call   401290 <puts@plt>
  402737:	48 8b 45 f8          	mov    -0x8(%rbp),%rax
  40273b:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
  402742:	00 00 
  402744:	75 30                	jne    402776 <launch+0xf0>
  402746:	c9                   	leave
  402747:	c3                   	ret
  402748:	48 8d 35 c5 1d 00 00 	lea    0x1dc5(%rip),%rsi        # 404514 <_IO_stdin_used+0x514>
  40274f:	bf 01 00 00 00       	mov    $0x1,%edi
  402754:	b8 00 00 00 00       	mov    $0x0,%eax
  402759:	e8 42 ec ff ff       	call   4013a0 <__printf_chk@plt>
  40275e:	eb ae                	jmp    40270e <launch+0x88>
  402760:	48 8d 3d ba 1d 00 00 	lea    0x1dba(%rip),%rdi        # 404521 <_IO_stdin_used+0x521>
  402767:	e8 24 eb ff ff       	call   401290 <puts@plt>
  40276c:	b8 00 00 00 00       	mov    $0x0,%eax
  402771:	e8 f4 f9 ff ff       	call   40216a <check_fail>
  402776:	e8 35 eb ff ff       	call   4012b0 <__stack_chk_fail@plt>

000000000040277b <stable_launch>:
  40277b:	f3 0f 1e fa          	endbr64
  40277f:	53                   	push   %rbx
  402780:	48 89 3d 61 4d 00 00 	mov    %rdi,0x4d61(%rip)        # 4074e8 <global_offset>
  402787:	41 b9 00 00 00 00    	mov    $0x0,%r9d
  40278d:	41 b8 00 00 00 00    	mov    $0x0,%r8d
  402793:	b9 32 01 00 00       	mov    $0x132,%ecx
  402798:	ba 07 00 00 00       	mov    $0x7,%edx
  40279d:	be 00 00 10 00       	mov    $0x100000,%esi
  4027a2:	bf 00 60 58 55       	mov    $0x55586000,%edi
  4027a7:	e8 14 eb ff ff       	call   4012c0 <mmap@plt>
  4027ac:	48 89 c3             	mov    %rax,%rbx
  4027af:	48 3d 00 60 58 55    	cmp    $0x55586000,%rax
  4027b5:	75 43                	jne    4027fa <stable_launch+0x7f>
  4027b7:	48 8d 90 f8 ff 0f 00 	lea    0xffff8(%rax),%rdx
  4027be:	48 89 15 6b 59 00 00 	mov    %rdx,0x596b(%rip)        # 408130 <stack_top>
  4027c5:	48 89 e0             	mov    %rsp,%rax
  4027c8:	48 89 d4             	mov    %rdx,%rsp
  4027cb:	48 89 c2             	mov    %rax,%rdx
  4027ce:	48 89 15 0b 4d 00 00 	mov    %rdx,0x4d0b(%rip)        # 4074e0 <global_save_stack>
  4027d5:	48 8b 3d 0c 4d 00 00 	mov    0x4d0c(%rip),%rdi        # 4074e8 <global_offset>
  4027dc:	e8 a5 fe ff ff       	call   402686 <launch>
  4027e1:	48 8b 05 f8 4c 00 00 	mov    0x4cf8(%rip),%rax        # 4074e0 <global_save_stack>
  4027e8:	48 89 c4             	mov    %rax,%rsp
  4027eb:	be 00 00 10 00       	mov    $0x100000,%esi
  4027f0:	48 89 df             	mov    %rbx,%rdi
  4027f3:	e8 98 eb ff ff       	call   401390 <munmap@plt>
  4027f8:	5b                   	pop    %rbx
  4027f9:	c3                   	ret
  4027fa:	be 00 00 10 00       	mov    $0x100000,%esi
  4027ff:	48 89 c7             	mov    %rax,%rdi
  402802:	e8 89 eb ff ff       	call   401390 <munmap@plt>
  402807:	b9 00 60 58 55       	mov    $0x55586000,%ecx
  40280c:	48 8d 15 cd 1e 00 00 	lea    0x1ecd(%rip),%rdx        # 4046e0 <_IO_stdin_used+0x6e0>
  402813:	be 01 00 00 00       	mov    $0x1,%esi
  402818:	48 8b 3d a1 4c 00 00 	mov    0x4ca1(%rip),%rdi        # 4074c0 <stderr@GLIBC_2.2.5>
  40281f:	b8 00 00 00 00       	mov    $0x0,%eax
  402824:	e8 e7 eb ff ff       	call   401410 <__fprintf_chk@plt>
  402829:	bf 01 00 00 00       	mov    $0x1,%edi
  40282e:	e8 bd eb ff ff       	call   4013f0 <exit@plt>

0000000000402833 <rio_readinitb>:
  402833:	89 37                	mov    %esi,(%rdi)
  402835:	c7 47 04 00 00 00 00 	movl   $0x0,0x4(%rdi)
  40283c:	48 8d 47 10          	lea    0x10(%rdi),%rax
  402840:	48 89 47 08          	mov    %rax,0x8(%rdi)
  402844:	c3                   	ret

0000000000402845 <sigalrm_handler>:
  402845:	f3 0f 1e fa          	endbr64
  402849:	50                   	push   %rax
  40284a:	58                   	pop    %rax
  40284b:	48 83 ec 08          	sub    $0x8,%rsp
  40284f:	b9 00 00 00 00       	mov    $0x0,%ecx
  402854:	48 8d 15 c5 1e 00 00 	lea    0x1ec5(%rip),%rdx        # 404720 <trans_char+0x10>
  40285b:	be 01 00 00 00       	mov    $0x1,%esi
  402860:	48 8b 3d 59 4c 00 00 	mov    0x4c59(%rip),%rdi        # 4074c0 <stderr@GLIBC_2.2.5>
  402867:	b8 00 00 00 00       	mov    $0x0,%eax
  40286c:	e8 9f eb ff ff       	call   401410 <__fprintf_chk@plt>
  402871:	bf 01 00 00 00       	mov    $0x1,%edi
  402876:	e8 75 eb ff ff       	call   4013f0 <exit@plt>

000000000040287b <rio_writen>:
  40287b:	41 55                	push   %r13
  40287d:	41 54                	push   %r12
  40287f:	55                   	push   %rbp
  402880:	53                   	push   %rbx
  402881:	48 83 ec 08          	sub    $0x8,%rsp
  402885:	41 89 fc             	mov    %edi,%r12d
  402888:	48 89 f5             	mov    %rsi,%rbp
  40288b:	49 89 d5             	mov    %rdx,%r13
  40288e:	48 89 d3             	mov    %rdx,%rbx
  402891:	eb 06                	jmp    402899 <rio_writen+0x1e>
  402893:	48 29 c3             	sub    %rax,%rbx
  402896:	48 01 c5             	add    %rax,%rbp
  402899:	48 85 db             	test   %rbx,%rbx
  40289c:	74 24                	je     4028c2 <rio_writen+0x47>
  40289e:	48 89 da             	mov    %rbx,%rdx
  4028a1:	48 89 ee             	mov    %rbp,%rsi
  4028a4:	44 89 e7             	mov    %r12d,%edi
  4028a7:	e8 f4 e9 ff ff       	call   4012a0 <write@plt>
  4028ac:	48 85 c0             	test   %rax,%rax
  4028af:	7f e2                	jg     402893 <rio_writen+0x18>
  4028b1:	e8 9a e9 ff ff       	call   401250 <__errno_location@plt>
  4028b6:	83 38 04             	cmpl   $0x4,(%rax)
  4028b9:	75 15                	jne    4028d0 <rio_writen+0x55>
  4028bb:	b8 00 00 00 00       	mov    $0x0,%eax
  4028c0:	eb d1                	jmp    402893 <rio_writen+0x18>
  4028c2:	4c 89 e8             	mov    %r13,%rax
  4028c5:	48 83 c4 08          	add    $0x8,%rsp
  4028c9:	5b                   	pop    %rbx
  4028ca:	5d                   	pop    %rbp
  4028cb:	41 5c                	pop    %r12
  4028cd:	41 5d                	pop    %r13
  4028cf:	c3                   	ret
  4028d0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
  4028d7:	eb ec                	jmp    4028c5 <rio_writen+0x4a>

00000000004028d9 <rio_read>:
  4028d9:	41 55                	push   %r13
  4028db:	41 54                	push   %r12
  4028dd:	55                   	push   %rbp
  4028de:	53                   	push   %rbx
  4028df:	48 83 ec 08          	sub    $0x8,%rsp
  4028e3:	48 89 fb             	mov    %rdi,%rbx
  4028e6:	49 89 f5             	mov    %rsi,%r13
  4028e9:	49 89 d4             	mov    %rdx,%r12
  4028ec:	eb 17                	jmp    402905 <rio_read+0x2c>
  4028ee:	e8 5d e9 ff ff       	call   401250 <__errno_location@plt>
  4028f3:	83 38 04             	cmpl   $0x4,(%rax)
  4028f6:	74 0d                	je     402905 <rio_read+0x2c>
  4028f8:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
  4028ff:	eb 54                	jmp    402955 <rio_read+0x7c>
  402901:	48 89 6b 08          	mov    %rbp,0x8(%rbx)
  402905:	8b 6b 04             	mov    0x4(%rbx),%ebp
  402908:	85 ed                	test   %ebp,%ebp
  40290a:	7f 23                	jg     40292f <rio_read+0x56>
  40290c:	48 8d 6b 10          	lea    0x10(%rbx),%rbp
  402910:	8b 3b                	mov    (%rbx),%edi
  402912:	ba 00 20 00 00       	mov    $0x2000,%edx
  402917:	48 89 ee             	mov    %rbp,%rsi
  40291a:	e8 e1 e9 ff ff       	call   401300 <read@plt>
  40291f:	89 43 04             	mov    %eax,0x4(%rbx)
  402922:	85 c0                	test   %eax,%eax
  402924:	78 c8                	js     4028ee <rio_read+0x15>
  402926:	75 d9                	jne    402901 <rio_read+0x28>
  402928:	b8 00 00 00 00       	mov    $0x0,%eax
  40292d:	eb 26                	jmp    402955 <rio_read+0x7c>
  40292f:	89 e8                	mov    %ebp,%eax
  402931:	4c 39 e0             	cmp    %r12,%rax
  402934:	72 03                	jb     402939 <rio_read+0x60>
  402936:	44 89 e5             	mov    %r12d,%ebp
  402939:	4c 63 e5             	movslq %ebp,%r12
  40293c:	48 8b 73 08          	mov    0x8(%rbx),%rsi
  402940:	4c 89 e2             	mov    %r12,%rdx
  402943:	4c 89 ef             	mov    %r13,%rdi
  402946:	e8 05 ea ff ff       	call   401350 <memcpy@plt>
  40294b:	4c 01 63 08          	add    %r12,0x8(%rbx)
  40294f:	29 6b 04             	sub    %ebp,0x4(%rbx)
  402952:	4c 89 e0             	mov    %r12,%rax
  402955:	48 83 c4 08          	add    $0x8,%rsp
  402959:	5b                   	pop    %rbx
  40295a:	5d                   	pop    %rbp
  40295b:	41 5c                	pop    %r12
  40295d:	41 5d                	pop    %r13
  40295f:	c3                   	ret

0000000000402960 <rio_readlineb>:
  402960:	41 55                	push   %r13
  402962:	41 54                	push   %r12
  402964:	55                   	push   %rbp
  402965:	53                   	push   %rbx
  402966:	48 83 ec 18          	sub    $0x18,%rsp
  40296a:	49 89 fd             	mov    %rdi,%r13
  40296d:	48 89 f5             	mov    %rsi,%rbp
  402970:	49 89 d4             	mov    %rdx,%r12
  402973:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
  40297a:	00 00 
  40297c:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  402981:	31 c0                	xor    %eax,%eax
  402983:	bb 01 00 00 00       	mov    $0x1,%ebx
  402988:	eb 18                	jmp    4029a2 <rio_readlineb+0x42>
  40298a:	85 c0                	test   %eax,%eax
  40298c:	75 65                	jne    4029f3 <rio_readlineb+0x93>
  40298e:	48 83 fb 01          	cmp    $0x1,%rbx
  402992:	75 3d                	jne    4029d1 <rio_readlineb+0x71>
  402994:	b8 00 00 00 00       	mov    $0x0,%eax
  402999:	eb 3d                	jmp    4029d8 <rio_readlineb+0x78>
  40299b:	48 83 c3 01          	add    $0x1,%rbx
  40299f:	48 89 d5             	mov    %rdx,%rbp
  4029a2:	4c 39 e3             	cmp    %r12,%rbx
  4029a5:	73 2a                	jae    4029d1 <rio_readlineb+0x71>
  4029a7:	48 8d 74 24 07       	lea    0x7(%rsp),%rsi
  4029ac:	ba 01 00 00 00       	mov    $0x1,%edx
  4029b1:	4c 89 ef             	mov    %r13,%rdi
  4029b4:	e8 20 ff ff ff       	call   4028d9 <rio_read>
  4029b9:	83 f8 01             	cmp    $0x1,%eax
  4029bc:	75 cc                	jne    40298a <rio_readlineb+0x2a>
  4029be:	48 8d 55 01          	lea    0x1(%rbp),%rdx
  4029c2:	0f b6 44 24 07       	movzbl 0x7(%rsp),%eax
  4029c7:	88 45 00             	mov    %al,0x0(%rbp)
  4029ca:	3c 0a                	cmp    $0xa,%al
  4029cc:	75 cd                	jne    40299b <rio_readlineb+0x3b>
  4029ce:	48 89 d5             	mov    %rdx,%rbp
  4029d1:	c6 45 00 00          	movb   $0x0,0x0(%rbp)
  4029d5:	48 89 d8             	mov    %rbx,%rax
  4029d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  4029dd:	64 48 33 0c 25 28 00 	xor    %fs:0x28,%rcx
  4029e4:	00 00 
  4029e6:	75 14                	jne    4029fc <rio_readlineb+0x9c>
  4029e8:	48 83 c4 18          	add    $0x18,%rsp
  4029ec:	5b                   	pop    %rbx
  4029ed:	5d                   	pop    %rbp
  4029ee:	41 5c                	pop    %r12
  4029f0:	41 5d                	pop    %r13
  4029f2:	c3                   	ret
  4029f3:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
  4029fa:	eb dc                	jmp    4029d8 <rio_readlineb+0x78>
  4029fc:	e8 af e8 ff ff       	call   4012b0 <__stack_chk_fail@plt>

0000000000402a01 <urlencode>:
  402a01:	41 54                	push   %r12
  402a03:	55                   	push   %rbp
  402a04:	53                   	push   %rbx
  402a05:	48 83 ec 10          	sub    $0x10,%rsp
  402a09:	48 89 fb             	mov    %rdi,%rbx
  402a0c:	48 89 f5             	mov    %rsi,%rbp
  402a0f:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
  402a16:	00 00 
  402a18:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  402a1d:	31 c0                	xor    %eax,%eax
  402a1f:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
  402a26:	f2 ae                	repnz scas %es:(%rdi),%al
  402a28:	48 f7 d1             	not    %rcx
  402a2b:	8d 41 ff             	lea    -0x1(%rcx),%eax
  402a2e:	eb 0f                	jmp    402a3f <urlencode+0x3e>
  402a30:	44 88 45 00          	mov    %r8b,0x0(%rbp)
  402a34:	48 8d 6d 01          	lea    0x1(%rbp),%rbp
  402a38:	48 83 c3 01          	add    $0x1,%rbx
  402a3c:	44 89 e0             	mov    %r12d,%eax
  402a3f:	44 8d 60 ff          	lea    -0x1(%rax),%r12d
  402a43:	85 c0                	test   %eax,%eax
  402a45:	0f 84 a8 00 00 00    	je     402af3 <urlencode+0xf2>
  402a4b:	44 0f b6 03          	movzbl (%rbx),%r8d
  402a4f:	41 80 f8 2a          	cmp    $0x2a,%r8b
  402a53:	0f 94 c2             	sete   %dl
  402a56:	41 80 f8 2d          	cmp    $0x2d,%r8b
  402a5a:	0f 94 c0             	sete   %al
  402a5d:	08 c2                	or     %al,%dl
  402a5f:	75 cf                	jne    402a30 <urlencode+0x2f>
  402a61:	41 80 f8 2e          	cmp    $0x2e,%r8b
  402a65:	74 c9                	je     402a30 <urlencode+0x2f>
  402a67:	41 80 f8 5f          	cmp    $0x5f,%r8b
  402a6b:	74 c3                	je     402a30 <urlencode+0x2f>
  402a6d:	41 8d 40 d0          	lea    -0x30(%r8),%eax
  402a71:	3c 09                	cmp    $0x9,%al
  402a73:	76 bb                	jbe    402a30 <urlencode+0x2f>
  402a75:	41 8d 40 bf          	lea    -0x41(%r8),%eax
  402a79:	3c 19                	cmp    $0x19,%al
  402a7b:	76 b3                	jbe    402a30 <urlencode+0x2f>
  402a7d:	41 8d 40 9f          	lea    -0x61(%r8),%eax
  402a81:	3c 19                	cmp    $0x19,%al
  402a83:	76 ab                	jbe    402a30 <urlencode+0x2f>
  402a85:	41 80 f8 20          	cmp    $0x20,%r8b
  402a89:	74 56                	je     402ae1 <urlencode+0xe0>
  402a8b:	41 8d 40 e0          	lea    -0x20(%r8),%eax
  402a8f:	3c 5f                	cmp    $0x5f,%al
  402a91:	0f 96 c2             	setbe  %dl
  402a94:	41 80 f8 09          	cmp    $0x9,%r8b
  402a98:	0f 94 c0             	sete   %al
  402a9b:	08 c2                	or     %al,%dl
  402a9d:	74 4f                	je     402aee <urlencode+0xed>
  402a9f:	48 89 e7             	mov    %rsp,%rdi
  402aa2:	45 0f b6 c0          	movzbl %r8b,%r8d
  402aa6:	48 8d 0d 08 1d 00 00 	lea    0x1d08(%rip),%rcx        # 4047b5 <trans_char+0xa5>
  402aad:	ba 08 00 00 00       	mov    $0x8,%edx
  402ab2:	be 01 00 00 00       	mov    $0x1,%esi
  402ab7:	b8 00 00 00 00       	mov    $0x0,%eax
  402abc:	e8 6f e9 ff ff       	call   401430 <__sprintf_chk@plt>
  402ac1:	0f b6 04 24          	movzbl (%rsp),%eax
  402ac5:	88 45 00             	mov    %al,0x0(%rbp)
  402ac8:	0f b6 44 24 01       	movzbl 0x1(%rsp),%eax
  402acd:	88 45 01             	mov    %al,0x1(%rbp)
  402ad0:	0f b6 44 24 02       	movzbl 0x2(%rsp),%eax
  402ad5:	88 45 02             	mov    %al,0x2(%rbp)
  402ad8:	48 8d 6d 03          	lea    0x3(%rbp),%rbp
  402adc:	e9 57 ff ff ff       	jmp    402a38 <urlencode+0x37>
  402ae1:	c6 45 00 2b          	movb   $0x2b,0x0(%rbp)
  402ae5:	48 8d 6d 01          	lea    0x1(%rbp),%rbp
  402ae9:	e9 4a ff ff ff       	jmp    402a38 <urlencode+0x37>
  402aee:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  402af3:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  402af8:	64 48 33 34 25 28 00 	xor    %fs:0x28,%rsi
  402aff:	00 00 
  402b01:	75 09                	jne    402b0c <urlencode+0x10b>
  402b03:	48 83 c4 10          	add    $0x10,%rsp
  402b07:	5b                   	pop    %rbx
  402b08:	5d                   	pop    %rbp
  402b09:	41 5c                	pop    %r12
  402b0b:	c3                   	ret
  402b0c:	e8 9f e7 ff ff       	call   4012b0 <__stack_chk_fail@plt>

0000000000402b11 <submitr>:
  402b11:	f3 0f 1e fa          	endbr64
  402b15:	41 57                	push   %r15
  402b17:	41 56                	push   %r14
  402b19:	41 55                	push   %r13
  402b1b:	41 54                	push   %r12
  402b1d:	55                   	push   %rbp
  402b1e:	53                   	push   %rbx
  402b1f:	4c 8d 9c 24 00 60 ff 	lea    -0xa000(%rsp),%r11
  402b26:	ff 
  402b27:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
  402b2e:	48 83 0c 24 00       	orq    $0x0,(%rsp)
  402b33:	4c 39 dc             	cmp    %r11,%rsp
  402b36:	75 ef                	jne    402b27 <submitr+0x16>
  402b38:	48 83 ec 68          	sub    $0x68,%rsp
  402b3c:	49 89 fc             	mov    %rdi,%r12
  402b3f:	89 74 24 14          	mov    %esi,0x14(%rsp)
  402b43:	49 89 d6             	mov    %rdx,%r14
  402b46:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
  402b4b:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
  402b50:	4d 89 cd             	mov    %r9,%r13
  402b53:	48 8b ac 24 a0 a0 00 	mov    0xa0a0(%rsp),%rbp
  402b5a:	00 
  402b5b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
  402b62:	00 00 
  402b64:	48 89 84 24 58 a0 00 	mov    %rax,0xa058(%rsp)
  402b6b:	00 
  402b6c:	31 c0                	xor    %eax,%eax
  402b6e:	c7 44 24 2c 00 00 00 	movl   $0x0,0x2c(%rsp)
  402b75:	00 
  402b76:	ba 00 00 00 00       	mov    $0x0,%edx
  402b7b:	be 01 00 00 00       	mov    $0x1,%esi
  402b80:	bf 02 00 00 00       	mov    $0x2,%edi
  402b85:	e8 b6 e8 ff ff       	call   401440 <socket@plt>
  402b8a:	85 c0                	test   %eax,%eax
  402b8c:	0f 88 a0 02 00 00    	js     402e32 <submitr+0x321>
  402b92:	89 c3                	mov    %eax,%ebx
  402b94:	4c 89 e7             	mov    %r12,%rdi
  402b97:	e8 84 e7 ff ff       	call   401320 <gethostbyname@plt>
  402b9c:	48 85 c0             	test   %rax,%rax
  402b9f:	0f 84 d9 02 00 00    	je     402e7e <submitr+0x36d>
  402ba5:	4c 8d 7c 24 30       	lea    0x30(%rsp),%r15
  402baa:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
  402bb1:	00 00 
  402bb3:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
  402bba:	00 00 
  402bbc:	66 c7 44 24 30 02 00 	movw   $0x2,0x30(%rsp)
  402bc3:	48 63 50 14          	movslq 0x14(%rax),%rdx
  402bc7:	48 8b 40 18          	mov    0x18(%rax),%rax
  402bcb:	48 8b 30             	mov    (%rax),%rsi
  402bce:	48 8d 7c 24 34       	lea    0x34(%rsp),%rdi
  402bd3:	b9 0c 00 00 00       	mov    $0xc,%ecx
  402bd8:	e8 53 e7 ff ff       	call   401330 <__memmove_chk@plt>
  402bdd:	0f b7 74 24 14       	movzwl 0x14(%rsp),%esi
  402be2:	66 c1 c6 08          	rol    $0x8,%si
  402be6:	66 89 74 24 32       	mov    %si,0x32(%rsp)
  402beb:	ba 10 00 00 00       	mov    $0x10,%edx
  402bf0:	4c 89 fe             	mov    %r15,%rsi
  402bf3:	89 df                	mov    %ebx,%edi
  402bf5:	e8 06 e8 ff ff       	call   401400 <connect@plt>
  402bfa:	85 c0                	test   %eax,%eax
  402bfc:	0f 88 e4 02 00 00    	js     402ee6 <submitr+0x3d5>
  402c02:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
  402c09:	b8 00 00 00 00       	mov    $0x0,%eax
  402c0e:	4c 89 c1             	mov    %r8,%rcx
  402c11:	4c 89 ef             	mov    %r13,%rdi
  402c14:	f2 ae                	repnz scas %es:(%rdi),%al
  402c16:	48 89 ca             	mov    %rcx,%rdx
  402c19:	48 f7 d2             	not    %rdx
  402c1c:	4c 89 c1             	mov    %r8,%rcx
  402c1f:	4c 89 f7             	mov    %r14,%rdi
  402c22:	f2 ae                	repnz scas %es:(%rdi),%al
  402c24:	48 f7 d1             	not    %rcx
  402c27:	48 89 ce             	mov    %rcx,%rsi
  402c2a:	4c 89 c1             	mov    %r8,%rcx
  402c2d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  402c32:	f2 ae                	repnz scas %es:(%rdi),%al
  402c34:	48 f7 d1             	not    %rcx
  402c37:	48 8d 74 0e fe       	lea    -0x2(%rsi,%rcx,1),%rsi
  402c3c:	4c 89 c1             	mov    %r8,%rcx
  402c3f:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  402c44:	f2 ae                	repnz scas %es:(%rdi),%al
  402c46:	48 89 c8             	mov    %rcx,%rax
  402c49:	48 f7 d0             	not    %rax
  402c4c:	48 8d 4c 06 ff       	lea    -0x1(%rsi,%rax,1),%rcx
  402c51:	48 8d 44 52 fd       	lea    -0x3(%rdx,%rdx,2),%rax
  402c56:	48 8d 84 01 80 00 00 	lea    0x80(%rcx,%rax,1),%rax
  402c5d:	00 
  402c5e:	48 3d 00 20 00 00    	cmp    $0x2000,%rax
  402c64:	0f 87 d6 02 00 00    	ja     402f40 <submitr+0x42f>
  402c6a:	48 8d b4 24 50 40 00 	lea    0x4050(%rsp),%rsi
  402c71:	00 
  402c72:	b9 00 04 00 00       	mov    $0x400,%ecx
  402c77:	b8 00 00 00 00       	mov    $0x0,%eax
  402c7c:	48 89 f7             	mov    %rsi,%rdi
  402c7f:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  402c82:	4c 89 ef             	mov    %r13,%rdi
  402c85:	e8 77 fd ff ff       	call   402a01 <urlencode>
  402c8a:	85 c0                	test   %eax,%eax
  402c8c:	0f 88 21 03 00 00    	js     402fb3 <submitr+0x4a2>
  402c92:	4c 8d bc 24 50 20 00 	lea    0x2050(%rsp),%r15
  402c99:	00 
  402c9a:	41 54                	push   %r12
  402c9c:	48 8d 84 24 58 40 00 	lea    0x4058(%rsp),%rax
  402ca3:	00 
  402ca4:	50                   	push   %rax
  402ca5:	4d 89 f1             	mov    %r14,%r9
  402ca8:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
  402cad:	48 8d 0d 94 1a 00 00 	lea    0x1a94(%rip),%rcx        # 404748 <trans_char+0x38>
  402cb4:	ba 00 20 00 00       	mov    $0x2000,%edx
  402cb9:	be 01 00 00 00       	mov    $0x1,%esi
  402cbe:	4c 89 ff             	mov    %r15,%rdi
  402cc1:	b8 00 00 00 00       	mov    $0x0,%eax
  402cc6:	e8 65 e7 ff ff       	call   401430 <__sprintf_chk@plt>
  402ccb:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
  402cd2:	b8 00 00 00 00       	mov    $0x0,%eax
  402cd7:	4c 89 ff             	mov    %r15,%rdi
  402cda:	f2 ae                	repnz scas %es:(%rdi),%al
  402cdc:	48 f7 d1             	not    %rcx
  402cdf:	48 8d 51 ff          	lea    -0x1(%rcx),%rdx
  402ce3:	4c 89 fe             	mov    %r15,%rsi
  402ce6:	89 df                	mov    %ebx,%edi
  402ce8:	e8 8e fb ff ff       	call   40287b <rio_writen>
  402ced:	48 83 c4 10          	add    $0x10,%rsp
  402cf1:	48 85 c0             	test   %rax,%rax
  402cf4:	0f 88 44 03 00 00    	js     40303e <submitr+0x52d>
  402cfa:	4c 8d 64 24 40       	lea    0x40(%rsp),%r12
  402cff:	89 de                	mov    %ebx,%esi
  402d01:	4c 89 e7             	mov    %r12,%rdi
  402d04:	e8 2a fb ff ff       	call   402833 <rio_readinitb>
  402d09:	48 8d b4 24 50 20 00 	lea    0x2050(%rsp),%rsi
  402d10:	00 
  402d11:	ba 00 20 00 00       	mov    $0x2000,%edx
  402d16:	4c 89 e7             	mov    %r12,%rdi
  402d19:	e8 42 fc ff ff       	call   402960 <rio_readlineb>
  402d1e:	48 85 c0             	test   %rax,%rax
  402d21:	0f 8e 86 03 00 00    	jle    4030ad <submitr+0x59c>
  402d27:	48 8d 4c 24 2c       	lea    0x2c(%rsp),%rcx
  402d2c:	48 8d 94 24 50 60 00 	lea    0x6050(%rsp),%rdx
  402d33:	00 
  402d34:	48 8d bc 24 50 20 00 	lea    0x2050(%rsp),%rdi
  402d3b:	00 
  402d3c:	4c 8d 84 24 50 80 00 	lea    0x8050(%rsp),%r8
  402d43:	00 
  402d44:	48 8d 35 71 1a 00 00 	lea    0x1a71(%rip),%rsi        # 4047bc <trans_char+0xac>
  402d4b:	b8 00 00 00 00       	mov    $0x0,%eax
  402d50:	e8 2b e6 ff ff       	call   401380 <__isoc99_sscanf@plt>
  402d55:	48 8d b4 24 50 20 00 	lea    0x2050(%rsp),%rsi
  402d5c:	00 
  402d5d:	b9 03 00 00 00       	mov    $0x3,%ecx
  402d62:	48 8d 3d 6a 1a 00 00 	lea    0x1a6a(%rip),%rdi        # 4047d3 <trans_char+0xc3>
  402d69:	f3 a6                	repz cmpsb %es:(%rdi),%ds:(%rsi)
  402d6b:	0f 97 c0             	seta   %al
  402d6e:	1c 00                	sbb    $0x0,%al
  402d70:	84 c0                	test   %al,%al
  402d72:	0f 84 b3 03 00 00    	je     40312b <submitr+0x61a>
  402d78:	48 8d b4 24 50 20 00 	lea    0x2050(%rsp),%rsi
  402d7f:	00 
  402d80:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
  402d85:	ba 00 20 00 00       	mov    $0x2000,%edx
  402d8a:	e8 d1 fb ff ff       	call   402960 <rio_readlineb>
  402d8f:	48 85 c0             	test   %rax,%rax
  402d92:	7f c1                	jg     402d55 <submitr+0x244>
  402d94:	48 b8 45 72 72 6f 72 	movabs $0x43203a726f727245,%rax
  402d9b:	3a 20 43 
  402d9e:	48 ba 6c 69 65 6e 74 	movabs $0x6e7520746e65696c,%rdx
  402da5:	20 75 6e 
  402da8:	48 89 45 00          	mov    %rax,0x0(%rbp)
  402dac:	48 89 55 08          	mov    %rdx,0x8(%rbp)
  402db0:	48 b8 61 62 6c 65 20 	movabs $0x206f7420656c6261,%rax
  402db7:	74 6f 20 
  402dba:	48 ba 72 65 61 64 20 	movabs $0x6165682064616572,%rdx
  402dc1:	68 65 61 
  402dc4:	48 89 45 10          	mov    %rax,0x10(%rbp)
  402dc8:	48 89 55 18          	mov    %rdx,0x18(%rbp)
  402dcc:	48 b8 64 65 72 73 20 	movabs $0x6f72662073726564,%rax
  402dd3:	66 72 6f 
  402dd6:	48 ba 6d 20 74 68 65 	movabs $0x657220656874206d,%rdx
  402ddd:	20 72 65 
  402de0:	48 89 45 20          	mov    %rax,0x20(%rbp)
  402de4:	48 89 55 28          	mov    %rdx,0x28(%rbp)
  402de8:	48 b8 73 75 6c 74 20 	movabs $0x72657320746c7573,%rax
  402def:	73 65 72 
  402df2:	48 89 45 30          	mov    %rax,0x30(%rbp)
  402df6:	c7 45 38 76 65 72 00 	movl   $0x726576,0x38(%rbp)
  402dfd:	89 df                	mov    %ebx,%edi
  402dff:	e8 ec e4 ff ff       	call   4012f0 <close@plt>
  402e04:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  402e09:	48 8b 9c 24 58 a0 00 	mov    0xa058(%rsp),%rbx
  402e10:	00 
  402e11:	64 48 33 1c 25 28 00 	xor    %fs:0x28,%rbx
  402e18:	00 00 
  402e1a:	0f 85 7e 04 00 00    	jne    40329e <submitr+0x78d>
  402e20:	48 81 c4 68 a0 00 00 	add    $0xa068,%rsp
  402e27:	5b                   	pop    %rbx
  402e28:	5d                   	pop    %rbp
  402e29:	41 5c                	pop    %r12
  402e2b:	41 5d                	pop    %r13
  402e2d:	41 5e                	pop    %r14
  402e2f:	41 5f                	pop    %r15
  402e31:	c3                   	ret
  402e32:	48 b8 45 72 72 6f 72 	movabs $0x43203a726f727245,%rax
  402e39:	3a 20 43 
  402e3c:	48 ba 6c 69 65 6e 74 	movabs $0x6e7520746e65696c,%rdx
  402e43:	20 75 6e 
  402e46:	48 89 45 00          	mov    %rax,0x0(%rbp)
  402e4a:	48 89 55 08          	mov    %rdx,0x8(%rbp)
  402e4e:	48 b8 61 62 6c 65 20 	movabs $0x206f7420656c6261,%rax
  402e55:	74 6f 20 
  402e58:	48 ba 63 72 65 61 74 	movabs $0x7320657461657263,%rdx
  402e5f:	65 20 73 
  402e62:	48 89 45 10          	mov    %rax,0x10(%rbp)
  402e66:	48 89 55 18          	mov    %rdx,0x18(%rbp)
  402e6a:	c7 45 20 6f 63 6b 65 	movl   $0x656b636f,0x20(%rbp)
  402e71:	66 c7 45 24 74 00    	movw   $0x74,0x24(%rbp)
  402e77:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  402e7c:	eb 8b                	jmp    402e09 <submitr+0x2f8>
  402e7e:	48 b8 45 72 72 6f 72 	movabs $0x44203a726f727245,%rax
  402e85:	3a 20 44 
  402e88:	48 ba 4e 53 20 69 73 	movabs $0x6e7520736920534e,%rdx
  402e8f:	20 75 6e 
  402e92:	48 89 45 00          	mov    %rax,0x0(%rbp)
  402e96:	48 89 55 08          	mov    %rdx,0x8(%rbp)
  402e9a:	48 b8 61 62 6c 65 20 	movabs $0x206f7420656c6261,%rax
  402ea1:	74 6f 20 
  402ea4:	48 ba 72 65 73 6f 6c 	movabs $0x2065766c6f736572,%rdx
  402eab:	76 65 20 
  402eae:	48 89 45 10          	mov    %rax,0x10(%rbp)
  402eb2:	48 89 55 18          	mov    %rdx,0x18(%rbp)
  402eb6:	48 b8 73 65 72 76 65 	movabs $0x6120726576726573,%rax
  402ebd:	72 20 61 
  402ec0:	48 89 45 20          	mov    %rax,0x20(%rbp)
  402ec4:	c7 45 28 64 64 72 65 	movl   $0x65726464,0x28(%rbp)
  402ecb:	66 c7 45 2c 73 73    	movw   $0x7373,0x2c(%rbp)
  402ed1:	c6 45 2e 00          	movb   $0x0,0x2e(%rbp)
  402ed5:	89 df                	mov    %ebx,%edi
  402ed7:	e8 14 e4 ff ff       	call   4012f0 <close@plt>
  402edc:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  402ee1:	e9 23 ff ff ff       	jmp    402e09 <submitr+0x2f8>
  402ee6:	48 b8 45 72 72 6f 72 	movabs $0x55203a726f727245,%rax
  402eed:	3a 20 55 
  402ef0:	48 ba 6e 61 62 6c 65 	movabs $0x6f7420656c62616e,%rdx
  402ef7:	20 74 6f 
  402efa:	48 89 45 00          	mov    %rax,0x0(%rbp)
  402efe:	48 89 55 08          	mov    %rdx,0x8(%rbp)
  402f02:	48 b8 20 63 6f 6e 6e 	movabs $0x7463656e6e6f6320,%rax
  402f09:	65 63 74 
  402f0c:	48 ba 20 74 6f 20 74 	movabs $0x20656874206f7420,%rdx
  402f13:	68 65 20 
  402f16:	48 89 45 10          	mov    %rax,0x10(%rbp)
  402f1a:	48 89 55 18          	mov    %rdx,0x18(%rbp)
  402f1e:	c7 45 20 73 65 72 76 	movl   $0x76726573,0x20(%rbp)
  402f25:	66 c7 45 24 65 72    	movw   $0x7265,0x24(%rbp)
  402f2b:	c6 45 26 00          	movb   $0x0,0x26(%rbp)
  402f2f:	89 df                	mov    %ebx,%edi
  402f31:	e8 ba e3 ff ff       	call   4012f0 <close@plt>
  402f36:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  402f3b:	e9 c9 fe ff ff       	jmp    402e09 <submitr+0x2f8>
  402f40:	48 b8 45 72 72 6f 72 	movabs $0x52203a726f727245,%rax
  402f47:	3a 20 52 
  402f4a:	48 ba 65 73 75 6c 74 	movabs $0x747320746c757365,%rdx
  402f51:	20 73 74 
  402f54:	48 89 45 00          	mov    %rax,0x0(%rbp)
  402f58:	48 89 55 08          	mov    %rdx,0x8(%rbp)
  402f5c:	48 b8 72 69 6e 67 20 	movabs $0x6f6f7420676e6972,%rax
  402f63:	74 6f 6f 
  402f66:	48 ba 20 6c 61 72 67 	movabs $0x202e656772616c20,%rdx
  402f6d:	65 2e 20 
  402f70:	48 89 45 10          	mov    %rax,0x10(%rbp)
  402f74:	48 89 55 18          	mov    %rdx,0x18(%rbp)
  402f78:	48 b8 49 6e 63 72 65 	movabs $0x6573616572636e49,%rax
  402f7f:	61 73 65 
  402f82:	48 ba 20 53 55 42 4d 	movabs $0x5254494d42555320,%rdx
  402f89:	49 54 52 
  402f8c:	48 89 45 20          	mov    %rax,0x20(%rbp)
  402f90:	48 89 55 28          	mov    %rdx,0x28(%rbp)
  402f94:	48 b8 5f 4d 41 58 42 	movabs $0x46554258414d5f,%rax
  402f9b:	55 46 00 
  402f9e:	48 89 45 30          	mov    %rax,0x30(%rbp)
  402fa2:	89 df                	mov    %ebx,%edi
  402fa4:	e8 47 e3 ff ff       	call   4012f0 <close@plt>
  402fa9:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  402fae:	e9 56 fe ff ff       	jmp    402e09 <submitr+0x2f8>
  402fb3:	48 b8 45 72 72 6f 72 	movabs $0x52203a726f727245,%rax
  402fba:	3a 20 52 
  402fbd:	48 ba 65 73 75 6c 74 	movabs $0x747320746c757365,%rdx
  402fc4:	20 73 74 
  402fc7:	48 89 45 00          	mov    %rax,0x0(%rbp)
  402fcb:	48 89 55 08          	mov    %rdx,0x8(%rbp)
  402fcf:	48 b8 72 69 6e 67 20 	movabs $0x6e6f6320676e6972,%rax
  402fd6:	63 6f 6e 
  402fd9:	48 ba 74 61 69 6e 73 	movabs $0x6e6120736e696174,%rdx
  402fe0:	20 61 6e 
  402fe3:	48 89 45 10          	mov    %rax,0x10(%rbp)
  402fe7:	48 89 55 18          	mov    %rdx,0x18(%rbp)
  402feb:	48 b8 20 69 6c 6c 65 	movabs $0x6c6167656c6c6920,%rax
  402ff2:	67 61 6c 
  402ff5:	48 ba 20 6f 72 20 75 	movabs $0x72706e7520726f20,%rdx
  402ffc:	6e 70 72 
  402fff:	48 89 45 20          	mov    %rax,0x20(%rbp)
  403003:	48 89 55 28          	mov    %rdx,0x28(%rbp)
  403007:	48 b8 69 6e 74 61 62 	movabs $0x20656c6261746e69,%rax
  40300e:	6c 65 20 
  403011:	48 ba 63 68 61 72 61 	movabs $0x6574636172616863,%rdx
  403018:	63 74 65 
  40301b:	48 89 45 30          	mov    %rax,0x30(%rbp)
  40301f:	48 89 55 38          	mov    %rdx,0x38(%rbp)
  403023:	66 c7 45 40 72 2e    	movw   $0x2e72,0x40(%rbp)
  403029:	c6 45 42 00          	movb   $0x0,0x42(%rbp)
  40302d:	89 df                	mov    %ebx,%edi
  40302f:	e8 bc e2 ff ff       	call   4012f0 <close@plt>
  403034:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  403039:	e9 cb fd ff ff       	jmp    402e09 <submitr+0x2f8>
  40303e:	48 b8 45 72 72 6f 72 	movabs $0x43203a726f727245,%rax
  403045:	3a 20 43 
  403048:	48 ba 6c 69 65 6e 74 	movabs $0x6e7520746e65696c,%rdx
  40304f:	20 75 6e 
  403052:	48 89 45 00          	mov    %rax,0x0(%rbp)
  403056:	48 89 55 08          	mov    %rdx,0x8(%rbp)
  40305a:	48 b8 61 62 6c 65 20 	movabs $0x206f7420656c6261,%rax
  403061:	74 6f 20 
  403064:	48 ba 77 72 69 74 65 	movabs $0x6f74206574697277,%rdx
  40306b:	20 74 6f 
  40306e:	48 89 45 10          	mov    %rax,0x10(%rbp)
  403072:	48 89 55 18          	mov    %rdx,0x18(%rbp)
  403076:	48 b8 20 74 68 65 20 	movabs $0x7365722065687420,%rax
  40307d:	72 65 73 
  403080:	48 ba 75 6c 74 20 73 	movabs $0x7672657320746c75,%rdx
  403087:	65 72 76 
  40308a:	48 89 45 20          	mov    %rax,0x20(%rbp)
  40308e:	48 89 55 28          	mov    %rdx,0x28(%rbp)
  403092:	66 c7 45 30 65 72    	movw   $0x7265,0x30(%rbp)
  403098:	c6 45 32 00          	movb   $0x0,0x32(%rbp)
  40309c:	89 df                	mov    %ebx,%edi
  40309e:	e8 4d e2 ff ff       	call   4012f0 <close@plt>
  4030a3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  4030a8:	e9 5c fd ff ff       	jmp    402e09 <submitr+0x2f8>
  4030ad:	48 b8 45 72 72 6f 72 	movabs $0x43203a726f727245,%rax
  4030b4:	3a 20 43 
  4030b7:	48 ba 6c 69 65 6e 74 	movabs $0x6e7520746e65696c,%rdx
  4030be:	20 75 6e 
  4030c1:	48 89 45 00          	mov    %rax,0x0(%rbp)
  4030c5:	48 89 55 08          	mov    %rdx,0x8(%rbp)
  4030c9:	48 b8 61 62 6c 65 20 	movabs $0x206f7420656c6261,%rax
  4030d0:	74 6f 20 
  4030d3:	48 ba 72 65 61 64 20 	movabs $0x7269662064616572,%rdx
  4030da:	66 69 72 
  4030dd:	48 89 45 10          	mov    %rax,0x10(%rbp)
  4030e1:	48 89 55 18          	mov    %rdx,0x18(%rbp)
  4030e5:	48 b8 73 74 20 68 65 	movabs $0x6564616568207473,%rax
  4030ec:	61 64 65 
  4030ef:	48 ba 72 20 66 72 6f 	movabs $0x72206d6f72662072,%rdx
  4030f6:	6d 20 72 
  4030f9:	48 89 45 20          	mov    %rax,0x20(%rbp)
  4030fd:	48 89 55 28          	mov    %rdx,0x28(%rbp)
  403101:	48 b8 65 73 75 6c 74 	movabs $0x657320746c757365,%rax
  403108:	20 73 65 
  40310b:	48 89 45 30          	mov    %rax,0x30(%rbp)
  40310f:	c7 45 38 72 76 65 72 	movl   $0x72657672,0x38(%rbp)
  403116:	c6 45 3c 00          	movb   $0x0,0x3c(%rbp)
  40311a:	89 df                	mov    %ebx,%edi
  40311c:	e8 cf e1 ff ff       	call   4012f0 <close@plt>
  403121:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  403126:	e9 de fc ff ff       	jmp    402e09 <submitr+0x2f8>
  40312b:	48 8d b4 24 50 20 00 	lea    0x2050(%rsp),%rsi
  403132:	00 
  403133:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
  403138:	ba 00 20 00 00       	mov    $0x2000,%edx
  40313d:	e8 1e f8 ff ff       	call   402960 <rio_readlineb>
  403142:	48 85 c0             	test   %rax,%rax
  403145:	0f 8e 96 00 00 00    	jle    4031e1 <submitr+0x6d0>
  40314b:	44 8b 44 24 2c       	mov    0x2c(%rsp),%r8d
  403150:	41 81 f8 c8 00 00 00 	cmp    $0xc8,%r8d
  403157:	0f 85 08 01 00 00    	jne    403265 <submitr+0x754>
  40315d:	48 8d b4 24 50 20 00 	lea    0x2050(%rsp),%rsi
  403164:	00 
  403165:	48 89 ef             	mov    %rbp,%rdi
  403168:	e8 13 e1 ff ff       	call   401280 <strcpy@plt>
  40316d:	89 df                	mov    %ebx,%edi
  40316f:	e8 7c e1 ff ff       	call   4012f0 <close@plt>
  403174:	b9 04 00 00 00       	mov    $0x4,%ecx
  403179:	48 8d 3d 4d 16 00 00 	lea    0x164d(%rip),%rdi        # 4047cd <trans_char+0xbd>
  403180:	48 89 ee             	mov    %rbp,%rsi
  403183:	f3 a6                	repz cmpsb %es:(%rdi),%ds:(%rsi)
  403185:	0f 97 c0             	seta   %al
  403188:	1c 00                	sbb    $0x0,%al
  40318a:	0f be c0             	movsbl %al,%eax
  40318d:	85 c0                	test   %eax,%eax
  40318f:	0f 84 74 fc ff ff    	je     402e09 <submitr+0x2f8>
  403195:	b9 05 00 00 00       	mov    $0x5,%ecx
  40319a:	48 8d 3d 30 16 00 00 	lea    0x1630(%rip),%rdi        # 4047d1 <trans_char+0xc1>
  4031a1:	48 89 ee             	mov    %rbp,%rsi
  4031a4:	f3 a6                	repz cmpsb %es:(%rdi),%ds:(%rsi)
  4031a6:	0f 97 c0             	seta   %al
  4031a9:	1c 00                	sbb    $0x0,%al
  4031ab:	0f be c0             	movsbl %al,%eax
  4031ae:	85 c0                	test   %eax,%eax
  4031b0:	0f 84 53 fc ff ff    	je     402e09 <submitr+0x2f8>
  4031b6:	b9 03 00 00 00       	mov    $0x3,%ecx
  4031bb:	48 8d 3d 14 16 00 00 	lea    0x1614(%rip),%rdi        # 4047d6 <trans_char+0xc6>
  4031c2:	48 89 ee             	mov    %rbp,%rsi
  4031c5:	f3 a6                	repz cmpsb %es:(%rdi),%ds:(%rsi)
  4031c7:	0f 97 c0             	seta   %al
  4031ca:	1c 00                	sbb    $0x0,%al
  4031cc:	0f be c0             	movsbl %al,%eax
  4031cf:	85 c0                	test   %eax,%eax
  4031d1:	0f 84 32 fc ff ff    	je     402e09 <submitr+0x2f8>
  4031d7:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  4031dc:	e9 28 fc ff ff       	jmp    402e09 <submitr+0x2f8>
  4031e1:	48 b8 45 72 72 6f 72 	movabs $0x43203a726f727245,%rax
  4031e8:	3a 20 43 
  4031eb:	48 ba 6c 69 65 6e 74 	movabs $0x6e7520746e65696c,%rdx
  4031f2:	20 75 6e 
  4031f5:	48 89 45 00          	mov    %rax,0x0(%rbp)
  4031f9:	48 89 55 08          	mov    %rdx,0x8(%rbp)
  4031fd:	48 b8 61 62 6c 65 20 	movabs $0x206f7420656c6261,%rax
  403204:	74 6f 20 
  403207:	48 ba 72 65 61 64 20 	movabs $0x6174732064616572,%rdx
  40320e:	73 74 61 
  403211:	48 89 45 10          	mov    %rax,0x10(%rbp)
  403215:	48 89 55 18          	mov    %rdx,0x18(%rbp)
  403219:	48 b8 74 75 73 20 6d 	movabs $0x7373656d20737574,%rax
  403220:	65 73 73 
  403223:	48 ba 61 67 65 20 66 	movabs $0x6d6f726620656761,%rdx
  40322a:	72 6f 6d 
  40322d:	48 89 45 20          	mov    %rax,0x20(%rbp)
  403231:	48 89 55 28          	mov    %rdx,0x28(%rbp)
  403235:	48 b8 20 72 65 73 75 	movabs $0x20746c7573657220,%rax
  40323c:	6c 74 20 
  40323f:	48 89 45 30          	mov    %rax,0x30(%rbp)
  403243:	c7 45 38 73 65 72 76 	movl   $0x76726573,0x38(%rbp)
  40324a:	66 c7 45 3c 65 72    	movw   $0x7265,0x3c(%rbp)
  403250:	c6 45 3e 00          	movb   $0x0,0x3e(%rbp)
  403254:	89 df                	mov    %ebx,%edi
  403256:	e8 95 e0 ff ff       	call   4012f0 <close@plt>
  40325b:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  403260:	e9 a4 fb ff ff       	jmp    402e09 <submitr+0x2f8>
  403265:	4c 8d 8c 24 50 80 00 	lea    0x8050(%rsp),%r9
  40326c:	00 
  40326d:	48 8d 0d 14 15 00 00 	lea    0x1514(%rip),%rcx        # 404788 <trans_char+0x78>
  403274:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  40327b:	be 01 00 00 00       	mov    $0x1,%esi
  403280:	48 89 ef             	mov    %rbp,%rdi
  403283:	b8 00 00 00 00       	mov    $0x0,%eax
  403288:	e8 a3 e1 ff ff       	call   401430 <__sprintf_chk@plt>
  40328d:	89 df                	mov    %ebx,%edi
  40328f:	e8 5c e0 ff ff       	call   4012f0 <close@plt>
  403294:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  403299:	e9 6b fb ff ff       	jmp    402e09 <submitr+0x2f8>
  40329e:	e8 0d e0 ff ff       	call   4012b0 <__stack_chk_fail@plt>

00000000004032a3 <init_timeout>:
  4032a3:	f3 0f 1e fa          	endbr64
  4032a7:	85 ff                	test   %edi,%edi
  4032a9:	74 26                	je     4032d1 <init_timeout+0x2e>
  4032ab:	53                   	push   %rbx
  4032ac:	89 fb                	mov    %edi,%ebx
  4032ae:	78 1a                	js     4032ca <init_timeout+0x27>
  4032b0:	48 8d 35 8e f5 ff ff 	lea    -0xa72(%rip),%rsi        # 402845 <sigalrm_handler>
  4032b7:	bf 0e 00 00 00       	mov    $0xe,%edi
  4032bc:	e8 4f e0 ff ff       	call   401310 <signal@plt>
  4032c1:	89 df                	mov    %ebx,%edi
  4032c3:	e8 18 e0 ff ff       	call   4012e0 <alarm@plt>
  4032c8:	5b                   	pop    %rbx
  4032c9:	c3                   	ret
  4032ca:	bb 00 00 00 00       	mov    $0x0,%ebx
  4032cf:	eb df                	jmp    4032b0 <init_timeout+0xd>
  4032d1:	c3                   	ret

00000000004032d2 <init_driver>:
  4032d2:	f3 0f 1e fa          	endbr64
  4032d6:	41 54                	push   %r12
  4032d8:	55                   	push   %rbp
  4032d9:	53                   	push   %rbx
  4032da:	48 83 ec 20          	sub    $0x20,%rsp
  4032de:	48 89 fd             	mov    %rdi,%rbp
  4032e1:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
  4032e8:	00 00 
  4032ea:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  4032ef:	31 c0                	xor    %eax,%eax
  4032f1:	be 01 00 00 00       	mov    $0x1,%esi
  4032f6:	bf 0d 00 00 00       	mov    $0xd,%edi
  4032fb:	e8 10 e0 ff ff       	call   401310 <signal@plt>
  403300:	be 01 00 00 00       	mov    $0x1,%esi
  403305:	bf 1d 00 00 00       	mov    $0x1d,%edi
  40330a:	e8 01 e0 ff ff       	call   401310 <signal@plt>
  40330f:	be 01 00 00 00       	mov    $0x1,%esi
  403314:	bf 1d 00 00 00       	mov    $0x1d,%edi
  403319:	e8 f2 df ff ff       	call   401310 <signal@plt>
  40331e:	ba 00 00 00 00       	mov    $0x0,%edx
  403323:	be 01 00 00 00       	mov    $0x1,%esi
  403328:	bf 02 00 00 00       	mov    $0x2,%edi
  40332d:	e8 0e e1 ff ff       	call   401440 <socket@plt>
  403332:	85 c0                	test   %eax,%eax
  403334:	0f 88 9c 00 00 00    	js     4033d6 <init_driver+0x104>
  40333a:	89 c3                	mov    %eax,%ebx
  40333c:	48 8d 3d 9b 0f 00 00 	lea    0xf9b(%rip),%rdi        # 4042de <_IO_stdin_used+0x2de>
  403343:	e8 d8 df ff ff       	call   401320 <gethostbyname@plt>
  403348:	48 85 c0             	test   %rax,%rax
  40334b:	0f 84 d1 00 00 00    	je     403422 <init_driver+0x150>
  403351:	49 89 e4             	mov    %rsp,%r12
  403354:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
  40335b:	00 
  40335c:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
  403363:	00 00 
  403365:	66 c7 04 24 02 00    	movw   $0x2,(%rsp)
  40336b:	48 63 50 14          	movslq 0x14(%rax),%rdx
  40336f:	48 8b 40 18          	mov    0x18(%rax),%rax
  403373:	48 8b 30             	mov    (%rax),%rsi
  403376:	48 8d 7c 24 04       	lea    0x4(%rsp),%rdi
  40337b:	b9 0c 00 00 00       	mov    $0xc,%ecx
  403380:	e8 ab df ff ff       	call   401330 <__memmove_chk@plt>
  403385:	66 c7 44 24 02 65 92 	movw   $0x9265,0x2(%rsp)
  40338c:	ba 10 00 00 00       	mov    $0x10,%edx
  403391:	4c 89 e6             	mov    %r12,%rsi
  403394:	89 df                	mov    %ebx,%edi
  403396:	e8 65 e0 ff ff       	call   401400 <connect@plt>
  40339b:	85 c0                	test   %eax,%eax
  40339d:	0f 88 e7 00 00 00    	js     40348a <init_driver+0x1b8>
  4033a3:	89 df                	mov    %ebx,%edi
  4033a5:	e8 46 df ff ff       	call   4012f0 <close@plt>
  4033aa:	66 c7 45 00 4f 4b    	movw   $0x4b4f,0x0(%rbp)
  4033b0:	c6 45 02 00          	movb   $0x0,0x2(%rbp)
  4033b4:	b8 00 00 00 00       	mov    $0x0,%eax
  4033b9:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  4033be:	64 48 33 0c 25 28 00 	xor    %fs:0x28,%rcx
  4033c5:	00 00 
  4033c7:	0f 85 10 01 00 00    	jne    4034dd <init_driver+0x20b>
  4033cd:	48 83 c4 20          	add    $0x20,%rsp
  4033d1:	5b                   	pop    %rbx
  4033d2:	5d                   	pop    %rbp
  4033d3:	41 5c                	pop    %r12
  4033d5:	c3                   	ret
  4033d6:	48 b8 45 72 72 6f 72 	movabs $0x43203a726f727245,%rax
  4033dd:	3a 20 43 
  4033e0:	48 ba 6c 69 65 6e 74 	movabs $0x6e7520746e65696c,%rdx
  4033e7:	20 75 6e 
  4033ea:	48 89 45 00          	mov    %rax,0x0(%rbp)
  4033ee:	48 89 55 08          	mov    %rdx,0x8(%rbp)
  4033f2:	48 b8 61 62 6c 65 20 	movabs $0x206f7420656c6261,%rax
  4033f9:	74 6f 20 
  4033fc:	48 ba 63 72 65 61 74 	movabs $0x7320657461657263,%rdx
  403403:	65 20 73 
  403406:	48 89 45 10          	mov    %rax,0x10(%rbp)
  40340a:	48 89 55 18          	mov    %rdx,0x18(%rbp)
  40340e:	c7 45 20 6f 63 6b 65 	movl   $0x656b636f,0x20(%rbp)
  403415:	66 c7 45 24 74 00    	movw   $0x74,0x24(%rbp)
  40341b:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  403420:	eb 97                	jmp    4033b9 <init_driver+0xe7>
  403422:	48 b8 45 72 72 6f 72 	movabs $0x44203a726f727245,%rax
  403429:	3a 20 44 
  40342c:	48 ba 4e 53 20 69 73 	movabs $0x6e7520736920534e,%rdx
  403433:	20 75 6e 
  403436:	48 89 45 00          	mov    %rax,0x0(%rbp)
  40343a:	48 89 55 08          	mov    %rdx,0x8(%rbp)
  40343e:	48 b8 61 62 6c 65 20 	movabs $0x206f7420656c6261,%rax
  403445:	74 6f 20 
  403448:	48 ba 72 65 73 6f 6c 	movabs $0x2065766c6f736572,%rdx
  40344f:	76 65 20 
  403452:	48 89 45 10          	mov    %rax,0x10(%rbp)
  403456:	48 89 55 18          	mov    %rdx,0x18(%rbp)
  40345a:	48 b8 73 65 72 76 65 	movabs $0x6120726576726573,%rax
  403461:	72 20 61 
  403464:	48 89 45 20          	mov    %rax,0x20(%rbp)
  403468:	c7 45 28 64 64 72 65 	movl   $0x65726464,0x28(%rbp)
  40346f:	66 c7 45 2c 73 73    	movw   $0x7373,0x2c(%rbp)
  403475:	c6 45 2e 00          	movb   $0x0,0x2e(%rbp)
  403479:	89 df                	mov    %ebx,%edi
  40347b:	e8 70 de ff ff       	call   4012f0 <close@plt>
  403480:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  403485:	e9 2f ff ff ff       	jmp    4033b9 <init_driver+0xe7>
  40348a:	48 b8 45 72 72 6f 72 	movabs $0x55203a726f727245,%rax
  403491:	3a 20 55 
  403494:	48 ba 6e 61 62 6c 65 	movabs $0x6f7420656c62616e,%rdx
  40349b:	20 74 6f 
  40349e:	48 89 45 00          	mov    %rax,0x0(%rbp)
  4034a2:	48 89 55 08          	mov    %rdx,0x8(%rbp)
  4034a6:	48 b8 20 63 6f 6e 6e 	movabs $0x7463656e6e6f6320,%rax
  4034ad:	65 63 74 
  4034b0:	48 ba 20 74 6f 20 73 	movabs $0x76726573206f7420,%rdx
  4034b7:	65 72 76 
  4034ba:	48 89 45 10          	mov    %rax,0x10(%rbp)
  4034be:	48 89 55 18          	mov    %rdx,0x18(%rbp)
  4034c2:	66 c7 45 20 65 72    	movw   $0x7265,0x20(%rbp)
  4034c8:	c6 45 22 00          	movb   $0x0,0x22(%rbp)
  4034cc:	89 df                	mov    %ebx,%edi
  4034ce:	e8 1d de ff ff       	call   4012f0 <close@plt>
  4034d3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  4034d8:	e9 dc fe ff ff       	jmp    4033b9 <init_driver+0xe7>
  4034dd:	e8 ce dd ff ff       	call   4012b0 <__stack_chk_fail@plt>

00000000004034e2 <driver_post>:
  4034e2:	f3 0f 1e fa          	endbr64
  4034e6:	53                   	push   %rbx
  4034e7:	4c 89 cb             	mov    %r9,%rbx
  4034ea:	45 85 c0             	test   %r8d,%r8d
  4034ed:	75 18                	jne    403507 <driver_post+0x25>
  4034ef:	48 85 ff             	test   %rdi,%rdi
  4034f2:	74 05                	je     4034f9 <driver_post+0x17>
  4034f4:	80 3f 00             	cmpb   $0x0,(%rdi)
  4034f7:	75 37                	jne    403530 <driver_post+0x4e>
  4034f9:	66 c7 03 4f 4b       	movw   $0x4b4f,(%rbx)
  4034fe:	c6 43 02 00          	movb   $0x0,0x2(%rbx)
  403502:	44 89 c0             	mov    %r8d,%eax
  403505:	5b                   	pop    %rbx
  403506:	c3                   	ret
  403507:	48 89 ca             	mov    %rcx,%rdx
  40350a:	48 8d 35 c8 12 00 00 	lea    0x12c8(%rip),%rsi        # 4047d9 <trans_char+0xc9>
  403511:	bf 01 00 00 00       	mov    $0x1,%edi
  403516:	b8 00 00 00 00       	mov    $0x0,%eax
  40351b:	e8 80 de ff ff       	call   4013a0 <__printf_chk@plt>
  403520:	66 c7 03 4f 4b       	movw   $0x4b4f,(%rbx)
  403525:	c6 43 02 00          	movb   $0x0,0x2(%rbx)
  403529:	b8 00 00 00 00       	mov    $0x0,%eax
  40352e:	eb d5                	jmp    403505 <driver_post+0x23>
  403530:	48 83 ec 08          	sub    $0x8,%rsp
  403534:	41 51                	push   %r9
  403536:	49 89 c9             	mov    %rcx,%r9
  403539:	49 89 d0             	mov    %rdx,%r8
  40353c:	48 89 f9             	mov    %rdi,%rcx
  40353f:	48 89 f2             	mov    %rsi,%rdx
  403542:	be 92 65 00 00       	mov    $0x6592,%esi
  403547:	48 8d 3d 90 0d 00 00 	lea    0xd90(%rip),%rdi        # 4042de <_IO_stdin_used+0x2de>
  40354e:	e8 be f5 ff ff       	call   402b11 <submitr>
  403553:	48 83 c4 10          	add    $0x10,%rsp
  403557:	eb ac                	jmp    403505 <driver_post+0x23>

0000000000403559 <check>:
  403559:	f3 0f 1e fa          	endbr64
  40355d:	89 f8                	mov    %edi,%eax
  40355f:	c1 e8 1c             	shr    $0x1c,%eax
  403562:	74 1d                	je     403581 <check+0x28>
  403564:	b9 00 00 00 00       	mov    $0x0,%ecx
  403569:	83 f9 1f             	cmp    $0x1f,%ecx
  40356c:	7f 0d                	jg     40357b <check+0x22>
  40356e:	89 f8                	mov    %edi,%eax
  403570:	d3 e8                	shr    %cl,%eax
  403572:	3c 0a                	cmp    $0xa,%al
  403574:	74 11                	je     403587 <check+0x2e>
  403576:	83 c1 08             	add    $0x8,%ecx
  403579:	eb ee                	jmp    403569 <check+0x10>
  40357b:	b8 01 00 00 00       	mov    $0x1,%eax
  403580:	c3                   	ret
  403581:	b8 00 00 00 00       	mov    $0x0,%eax
  403586:	c3                   	ret
  403587:	b8 00 00 00 00       	mov    $0x0,%eax
  40358c:	c3                   	ret

000000000040358d <gencookie>:
  40358d:	f3 0f 1e fa          	endbr64
  403591:	53                   	push   %rbx
  403592:	83 c7 01             	add    $0x1,%edi
  403595:	e8 c6 dc ff ff       	call   401260 <srandom@plt>
  40359a:	e8 d1 dd ff ff       	call   401370 <random@plt>
  40359f:	48 89 c7             	mov    %rax,%rdi
  4035a2:	89 c3                	mov    %eax,%ebx
  4035a4:	e8 b0 ff ff ff       	call   403559 <check>
  4035a9:	85 c0                	test   %eax,%eax
  4035ab:	74 ed                	je     40359a <gencookie+0xd>
  4035ad:	89 d8                	mov    %ebx,%eax
  4035af:	5b                   	pop    %rbx
  4035b0:	c3                   	ret
  4035b1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  4035b8:	00 00 00 
  4035bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000004035c0 <__libc_csu_init>:
  4035c0:	f3 0f 1e fa          	endbr64
  4035c4:	41 57                	push   %r15
  4035c6:	4c 8d 3d 43 38 00 00 	lea    0x3843(%rip),%r15        # 406e10 <__frame_dummy_init_array_entry>
  4035cd:	41 56                	push   %r14
  4035cf:	49 89 d6             	mov    %rdx,%r14
  4035d2:	41 55                	push   %r13
  4035d4:	49 89 f5             	mov    %rsi,%r13
  4035d7:	41 54                	push   %r12
  4035d9:	41 89 fc             	mov    %edi,%r12d
  4035dc:	55                   	push   %rbp
  4035dd:	48 8d 2d 34 38 00 00 	lea    0x3834(%rip),%rbp        # 406e18 <__do_global_dtors_aux_fini_array_entry>
  4035e4:	53                   	push   %rbx
  4035e5:	4c 29 fd             	sub    %r15,%rbp
  4035e8:	48 83 ec 08          	sub    $0x8,%rsp
  4035ec:	e8 0f da ff ff       	call   401000 <_init>
  4035f1:	48 c1 fd 03          	sar    $0x3,%rbp
  4035f5:	74 1f                	je     403616 <__libc_csu_init+0x56>
  4035f7:	31 db                	xor    %ebx,%ebx
  4035f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  403600:	4c 89 f2             	mov    %r14,%rdx
  403603:	4c 89 ee             	mov    %r13,%rsi
  403606:	44 89 e7             	mov    %r12d,%edi
  403609:	41 ff 14 df          	call   *(%r15,%rbx,8)
  40360d:	48 83 c3 01          	add    $0x1,%rbx
  403611:	48 39 dd             	cmp    %rbx,%rbp
  403614:	75 ea                	jne    403600 <__libc_csu_init+0x40>
  403616:	48 83 c4 08          	add    $0x8,%rsp
  40361a:	5b                   	pop    %rbx
  40361b:	5d                   	pop    %rbp
  40361c:	41 5c                	pop    %r12
  40361e:	41 5d                	pop    %r13
  403620:	41 5e                	pop    %r14
  403622:	41 5f                	pop    %r15
  403624:	c3                   	ret
  403625:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  40362c:	00 00 00 00 

0000000000403630 <__libc_csu_fini>:
  403630:	f3 0f 1e fa          	endbr64
  403634:	c3                   	ret

Disassembly of section .fini:

0000000000403638 <_fini>:
  403638:	f3 0f 1e fa          	endbr64
  40363c:	48 83 ec 08          	sub    $0x8,%rsp
  403640:	48 83 c4 08          	add    $0x8,%rsp
  403644:	c3                   	ret
