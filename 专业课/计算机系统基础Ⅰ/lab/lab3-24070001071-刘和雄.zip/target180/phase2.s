movq $0x2c85ed77, %rdi
pushq $0x401f31
ret
